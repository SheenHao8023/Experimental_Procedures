import random
from psychopy import visual, core, data
import pandas as pd
# import pygame
from collections import deque

win1 = visual.Window(
    size=[1536, 864], fullscr=True, screen=0, 
    pos=[0, 0],  # 设置窗口位置
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color=[-0.5, -0.5, -0.5], colorSpace='rgb',
    blendMode='avg', useFBO=False,  # 禁用 FBO
    units="pix", multiSample=False)  # 禁用多重采样

class Character2:
    def __init__(self, maze, pos=None, controls=None):
        self.maze = maze
        self.pos = pos if pos else (0, 0)  # 默认位置为 (0, 0)
        self.controls = controls if controls else {'up': 'up', 'down': 'down', 'left': 'left', 'right': 'right'}
        self.goal = None  # goal 表示目标位置，可以是一个坐标元组或 None
        self.image = None  # 图像将在外部设置
        # self.goal_image = pygame.Surface((100, 100))  # 目标的图像或标记
        self.win = None  # 窗口将在外部设置
        self.far_position = None  # 最远位置
        self.near_position = None  # 最近位置
    
    def get_shortest_path(self, start_pos, goal_pos):
        """使用广度优先搜索（BFS）算法计算从 start_pos 到 goal_pos 的最短路径"""
        queue = deque([(start_pos, [start_pos])])
        visited = set()

        while queue:
            (x, y), path = queue.popleft()
            if (x, y) == goal_pos:
                return path

            visited.add((x, y))

            neighbors = []
            if x > 0 and self.maze.horizontal_matrix[y][x - 1]:  # left
                neighbors.append((x - 1, y))
            if x < self.maze.width - 1 and self.maze.horizontal_matrix[y][x]:  # right
                neighbors.append((x + 1, y))
            if y > 0 and self.maze.vertical_matrix[y - 1][x]:  # up
                neighbors.append((x, y - 1))
            if y < self.maze.height - 1 and self.maze.vertical_matrix[y][x]:  # down
                neighbors.append((x, y + 1))

            for neighbor in neighbors:
                if neighbor not in visited:
                    queue.append((neighbor, path + [neighbor]))
        return None  # No path found
    
    def calculate_path_length(self, start_pos, goal_pos):
        """计算从 start_pos 到 goal_pos 之间通过网格线的数量"""
        # 这里假设 `self.maze.get_shortest_path` 是一个返回路径的函数，
        # 路径包括从 start_pos 到 goal_pos 之间所有的网格线。
        path = self.get_shortest_path(start_pos, goal_pos)
        return len(path) if path else float('inf')  # 如果没有路径，则返回无限大
    
    def set_random_goal_position(self):
        """随机选择一个满足条件的坐标作为目标位置"""
        maze_width = self.maze.width
        maze_height = self.maze.height
        horizontal_matrix = self.maze.horizontal_matrix
        vertical_matrix = self.maze.vertical_matrix

        # 获取所有满足条件的位置坐标
        valid_positions = []
        for y in range(maze_height):
            for x in range(maze_width):
                if (y > 0 and vertical_matrix[y-1][x]) or \
                   (y < maze_height-1 and vertical_matrix[y][x]) or \
                   (x > 0 and horizontal_matrix[y][x-1]) or \
                   (x < maze_width-1 and horizontal_matrix[y][x]):
                    valid_positions.append((x, y))
        return valid_positions

    def setup_positions(self):
        """设置目标位置"""
        valid_positions = self.set_random_goal_position()
        if valid_positions:
            # 随机选择一个位置作为目标位置
            self.goal = random.choice(valid_positions)
            print(f"选择的目标位置: {self.goal}")
        else:
            print("没有找到满足条件的位置")
            
    def set_far_positions(self):
        """设置相对目标位置较远的位置"""
        if self.goal is None:
            raise ValueError("目标位置尚未设置。请先调用 set_random_goal_position 方法。")
        # 获取所有满足条件的位置
        valid_positions = self.set_random_goal_position()
        # 排除目标位置并筛选距离在8-10个网格线的远位置
        far_positions = [pos for pos in valid_positions if 8 <= self.calculate_path_length(pos, self.goal) <= 10 and pos != self.goal]
        if len(far_positions) >= 1:
            self.far_position = random.choice(far_positions)
            self.pos = self.far_position 
            print(f"far position: {self.far_position}")
        else:
            self.far_position = None
            print("没有找到符合条件的远距离位置")
    def set_near_positions(self):
        """设置相对目标位置较近的位置"""
        if self.goal is None:
            raise ValueError("目标位置尚未设置。请先调用 set_random_goal_position 方法。")
        # 获取所有满足条件的位置
        valid_positions = self.set_random_goal_position()
        # 排除目标位置并筛选距离在8-10个网格线的远位置
        near_positions = [pos for pos in valid_positions if 2 <= self.calculate_path_length(pos, self.goal) <= 4 and pos != self.goal]
        if len(near_positions) >= 1:
            self.near_position = random.choice(near_positions)
            self.pos = self.near_position 
            print(f"Near position: {self.near_position}")

        else:
            self.near_position = None
            print("没有找到符合条件的近距离位置")
    
    def move(self, direction):
        """移动角色"""
        x, y = self.pos
        new_pos = list(self.pos)

        if direction == 'up':
            new_pos[1] -= 1
        elif direction == 'down':
            new_pos[1] += 1
        elif direction == 'left':
            new_pos[0] -= 1
        elif direction == 'right':
            new_pos[0] += 1

        if not self.maze.is_wall(self.pos, tuple(new_pos)):
            self.pos = tuple(new_pos)
            return True #如果移动成功，move 方法返回 True
        else:
            self.rotate_clockwise()  #如果遇到墙壁而未能移动，执行旋转反馈
            return False  #move 方法返回 False

    def rotate_clockwise(self):
        """顺时针倒地90度动画并恢复"""
        if self.image and self.win:
            self.goal_image.draw()
            self.maze.draw_maze()
            win1.flip() 
            for angle in range(0, 91, 5):  # 每5度旋转一次，直到90度
                self.image.ori = angle
                self.image.draw()
                self.win.flip()
                #core.wait(0.05)
            
            for angle in range(90, -1, -5):  # 逆时针回到0度
                self.image.ori = angle
                self.image.draw()
                self.win.flip()
                #core.wait(0.05)

            # 恢复到初始状态
            self.image.ori = 0
            self.image.draw()
            self.win.flip()

    def handle_keys(self, keys):
        """处理按键并返回是否成功移动"""
        moved = False
        if self.controls and self.controls['up'] in keys:
            moved = self.move('up')
        elif self.controls and self.controls['down'] in keys:
            moved = self.move('down')
        elif self.controls and self.controls['left'] in keys:
            moved = self.move('left')
        elif self.controls and self.controls['right'] in keys:
            moved = self.move('right')
        return moved  # 返回是否成功移动

    def draw(self):
        """绘制角色图像和目标位置"""
        if self.win is None:
            raise ValueError("Window (win) is not set. Please set the window before calling draw().")

        if self.goal_image and self.goal:
            self.goal_image.pos = self.maze.get_node_position(*self.goal)  # 更新目标图像位置
            self.goal_image.draw()  # 绘制目标图像
        # self.goal_image = pygame.Surface((100, 100))
        if self.image:
            self.image.pos = self.maze.get_node_position(*self.pos)  # 更新角色图像位置
            self.image.draw()  # 绘制角色图像
            self.win.flip()  # 刷新窗口

        