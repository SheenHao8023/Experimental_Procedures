import random
from psychopy import visual, core, data
import pandas as pd
# import pygame
from collections import deque

class BaseMaze1:
    def __init__(self, width, height, win, draw_lines=True):
        self.width = width
        self.height = height
        self.win = win
        self.draw_lines = draw_lines  # 新增属性控制是否绘制线段
        # 初始化水平和垂直矩阵，假设所有节点最初都是连通的
        self.horizontal_matrix = [[1] * (self.width - 1) for _ in range(self.height)]
        self.vertical_matrix = [[1] * self.width for _ in range(self.height - 1)]
        self.grid_lines = {}  # 使用字典存储网格线，以便按位置访问
        self.dots = []
        self.cell_size_x = None
        self.cell_size_y = None
        self.screen_center_x = 0
        self.screen_center_y = 0

    def setup_grid(self):
        """设置网格的线条和节点"""
        cm_in_pixels = 2

        grid_width = min(self.win.size) - 2 * cm_in_pixels
        grid_height = min(self.win.size) - 2 * cm_in_pixels
        self.cell_size_x = grid_width / self.width
        self.cell_size_y = grid_height / self.height
        self.screen_center_x = 0
        self.screen_center_y = 0

        for y in range(self.height):
            for x in range(self.width):
                node_x = self.screen_center_x + (x - self.width / 2) * self.cell_size_x
                node_y = self.screen_center_y + (self.height / 2 - y) * self.cell_size_y
                dot = visual.Circle(self.win, radius=5, fillColor='cyan', pos=(node_x, node_y))
                self.dots.append(dot)

    def get_node_position(self, x, y):
        """根据网格坐标获取节点的屏幕坐标"""
        node_x = self.screen_center_x + (x - self.width / 2) * self.cell_size_x
        node_y = self.screen_center_y + (self.height / 2 - y) * self.cell_size_y
        return node_x, node_y

    def add_grid_line(self, start_x, start_y, end_x, end_y):
        """添加单条网格线并存储到字典中"""
        start_pos = self.get_node_position(start_x, start_y)
        end_pos = self.get_node_position(end_x, end_y)

        line_key = (start_pos, end_pos)
        reverse_key = (end_pos, start_pos)
        if line_key not in self.grid_lines and reverse_key not in self.grid_lines:
            line = visual.Line(self.win, start=start_pos, end=end_pos, lineColor='white', lineWidth=2)
            self.grid_lines[line_key] = line

    def delete_grid_line(self, start_x, start_y, end_x, end_y):
        """删除指定的网格线"""
        start_pos = self.get_node_position(start_x, start_y)
        end_pos = self.get_node_position(end_x, end_y)

        line_key = (start_pos, end_pos)
        reverse_key = (end_pos, start_pos)
        if line_key in self.grid_lines:
            self.grid_lines[line_key].setAutoDraw(False)
            del self.grid_lines[line_key]
        elif reverse_key in self.grid_lines:
            self.grid_lines[reverse_key].setAutoDraw(False)
            del self.grid_lines[reverse_key]

    def add_grid_from_matrix(self, matrix):
        """从矩阵中添加网格线，矩阵中的1表示要添加的网格线"""
        rows = len(matrix)
        cols = len(matrix[0]) if rows > 0 else 0

        for y in range(rows):
            for x in range(cols):
                if matrix[y][x] == 1:
                    # 添加水平线
                    if x < cols - 1 and matrix[y][x + 1] == 1:
                        self.add_grid_line(x, y, x + 1, y)
                    # 添加垂直线
                    if y < rows - 1 and matrix[y + 1][x] == 1:
                        self.add_grid_line(x, y, x, y + 1)

    def add_grid_from_matrices(self, horizontal_matrix, vertical_matrix):
        """从两个矩阵分别添加横线和纵线"""
        rows_h = len(horizontal_matrix)
        cols_h = len(horizontal_matrix[0]) if rows_h > 0 else 0

        rows_v = len(vertical_matrix)
        cols_v = len(vertical_matrix[0]) if rows_v > 0 else 0

        # 添加横向线条
        for y in range(rows_h):
            for x in range(cols_h):
                if horizontal_matrix[y][x] == 1:
                    self.add_grid_line(x, y, x + 1, y)

    # 添加纵向线条
        for y in range(rows_v):
            for x in range(cols_v):
                if vertical_matrix[y][x] == 1:
                    self.add_grid_line(x, y, x, y + 1)
    
    def is_wall(self, pos1, pos2):
        """检查两个相邻节点之间是否存在墙壁"""
        start_pos = self.get_node_position(*pos1)
        end_pos = self.get_node_position(*pos2)

        line_key = (start_pos, end_pos)
        reverse_key = (end_pos, start_pos)

        # 如果两者之间没有连接线段，则认为有墙壁
        if line_key not in self.grid_lines and reverse_key not in self.grid_lines:
            return True  # 有墙壁
        return False  # 没有墙壁
        
    def get_random_position(self):
        while True:
            random_pos = (random.randint(0, self.width - 1), random.randint(0, self.height - 1))
            if not self.is_wall(random_pos, random_pos):  # 使用相同的位置作为两个参数检查是否为墙壁
                return random_pos

    def draw_maze(self):
        """绘制所有未删除的网格线和节点"""
    # 先设置所有线段的 AutoDraw 为 False，以便清空之前的绘制
        for line in self.grid_lines.values():
            line.setAutoDraw(False)
    
    # 手动绘制线段
        if self.draw_lines:  # 仅当 draw_lines 为 True 时绘制线段
            for line in self.grid_lines.values():
                line.draw()

    # 然后绘制节点，确保节点在网格线上层
        for dot in self.dots:
            dot.draw()
        # self.draw_maze = pygame.Surface((100, 100))
        # 最后刷新窗口，显示更新
        self.win.flip()

