# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import gui, visual, core, data, event, logging, clock, colors, layout, parallel
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard
import random
# import pygame
from psychopy import visual, event, core
from BaseMaze1 import BaseMaze1  # 需要与此脚本在同一目录下
from Character2 import Character2

# pygame.init()
# --- Setup the Window ---
# 创建第一个窗口（屏幕0）
win1 = visual.Window(
    size=[1536, 864], fullscr=True, screen=0, 
    pos=[0, 0],  # 设置窗口位置
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color=[-0.5, -0.5, -0.5], colorSpace='rgb',
    blendMode='avg', useFBO=False,  # 禁用 FBO
    units="pix", multiSample=False)  # 禁用多重采样
win1.mouseVisible = False
screen1_size = win1.size
print(f"主屏幕的分辨率: {screen1_size}")
# store frame rate of monitor if we can measure it
# 获取每个窗口的帧率
expInfo = {}
expInfo['frameRate1'] = win1.getActualFrameRate()
if expInfo['frameRate1'] is not None:
    frameDur1 = 1.0 / round(expInfo['frameRate1'])
else:
    frameDur1 = 1.0 / 60.0  # 如果无法测量帧率，则假定为60Hz

# --- Setup input devices ---
ioConfig = {}   #暂未使用

maze_width = 7
maze_height = 7   # 设置迷宫的尺寸
screen_width, screen_height = win1.size # 获取屏幕尺寸
# 屏幕1上创建迷宫实例并显示线段
maze = BaseMaze1(maze_width, maze_height, win1, draw_lines=True)
maze.setup_grid()  # 初始化迷宫

# 定义迷宫矩阵
horizontal_matrix = [
    [1, 1, 1, 0, 1, 1],
    [1, 1, 1, 1, 0, 0],
    [1, 0, 1, 1, 0, 1],
    [1, 1, 0, 1, 1, 1],
    [0, 0, 1, 0, 0, 1],
    [0, 1, 0, 1, 1, 1],
    [1, 1, 0, 1, 1, 1]  #
]

vertical_matrix = [
    [1, 1, 1, 1, 1, 1, 1],  # 7列
    [0, 0, 1, 0, 0, 1, 0],  # 7列
    [1, 1, 0, 1, 1, 0, 1],  # 7列
    [1, 0, 1, 0, 1, 1, 1],  # 7列
    [1, 1, 1, 1, 0, 1, 1],  # 7列
    [0, 1, 0, 1, 1, 1, 0]   # 7列
]


# 从矩阵中添加网格线
maze.add_grid_from_matrices(horizontal_matrix, vertical_matrix)

# 创建角色实例，并将其起始位置设置在目标附近
char1 = Character2(maze=maze, controls={'up': 'w', 'down': 's', 'left': 'a', 'right': 'd'})  #移动方向和按键不匹配问题已解决
# 设置目标位置
char1.win = win1
char1.image = visual.ImageStim(win1, image='char2.png')
char1.goal_image = visual.ImageStim(win1, image='goal.png')

char1.setup_positions()  # 随机设置目标位置
char1.set_near_positions()

# 初次绘制迷宫和目标
maze.draw_maze()
char1.goal_image.pos = maze.get_node_position(*char1.goal)  # 设置目标图像的位置
char1.image.pos = maze.get_node_position(*char1.near_position) 
char1.goal_image.draw()
char1.image.draw()  # 绘制角色位置

# 创建一个 pygame Surface 用于始终显示的元素
# overlay_surface = pygame.Surface((1536, 864), pygame.SRCALPHA)
# overlay_surface.blit(maze.draw_maze(), (0, 0)) 

# 持续显示直到手动退出
while True:
    maze.draw_maze()
    char1.goal_image.draw()
    char1.image.draw()
    keys = event.getKeys()
    if 'escape' in keys:
        break  # 退出循环
    if keys:  #检测是否有按键被按下
        moved = char1.handle_keys(keys)  # 处理按键输入，并检查是否移动
        if moved:
            char1.draw()  
    # 使用 pygame Surface 绘制始终显示的元素
    # win.callOnFlip(pygame.image.tostring, overlay_surface, "raw", False)
    # core.wait(0.01)  # 控制循环刷新速度


win1.close()
core.quit()





