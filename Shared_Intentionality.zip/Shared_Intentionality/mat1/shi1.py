from psychopy import visual, core, data, event, logging
import random
import os

# Set up experiment info and window
expInfo = {'participant': '', 'session': '001'}
_thisDir = os.path.dirname(os.path.abspath(__file__))
expName = 'dual_screen_experiment'
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# Initialize ExperimentHandlers for parent and child
thisExp_p = data.ExperimentHandler(name=expName, version='', extraInfo=expInfo,
                                   runtimeInfo=None, originPath=_thisDir,
                                   savePickle=True, saveWideText=True,
                                   dataFileName=filename + '_parents')
thisExp_c = data.ExperimentHandler(name=expName, version='', extraInfo=expInfo,
                                   runtimeInfo=None, originPath=_thisDir,
                                   savePickle=True, saveWideText=True,
                                   dataFileName=filename + '_children')

# Setup windows for parents and children
win1 = visual.Window(size=(800, 600), fullscr=False, screen=0, winType='pyglet', allowGUI=True, allowStencil=False,
                     monitor='testMonitor', color=[0, 0, 0], colorSpace='rgb', blendMode='avg', useFBO=True)
win2 = visual.Window(size=(800, 600), fullscr=False, screen=1, winType='pyglet', allowGUI=True, allowStencil=False,
                     monitor='testMonitor', color=[0, 0, 0], colorSpace='rgb', blendMode='avg', useFBO=True)

# Initialize stimuli components
intro_parents1 = visual.TextStim(win=win1, text='请认真思考', units='norm')
intro_children1 = visual.TextStim(win=win2, text='请认真思考', units='norm')
polygon_iti_1 = visual.ShapeStim(win=win1, name='polygon_iti_1', vertices='cross', units='norm',
                                 size=(0.05, 0.05), ori=0.0, pos=(0, 0), anchor='center',
                                 lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor='white',
                                 opacity=1.0, depth=-1.0, interpolate=True)
polygon_iti_2 = visual.ShapeStim(win=win2, name='polygon_iti_2', vertices='cross', units='norm',
                                 size=(0.05, 0.05), ori=0.0, pos=(0, 0), anchor='center',
                                 lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor='white',
                                 opacity=1.0, depth=-1.0, interpolate=True)

# Create TrialHandler to manage trials
trials_2 = data.TrialHandler(nReps=1.0, method='sequential',
                             extraInfo=expInfo, originPath=-1,
                             trialList=data.importConditions('mat1/object.xlsx'),
                             seed=None, name='trials_2')
thisExp_p.addLoop(trials_2)  # Add loop to parents' experiment handler
thisExp_c.addLoop(trials_2)  # Add loop to children's experiment handler

# Run trials
for thisTrial_2 in trials_2:
    # --- Prepare to start Routine "思考" ---
    continueRoutine = True
    routineTimer = core.Clock()
    routineTimer.reset()
    # Record the start time of the routine for both p and c
    thisExp_p.addData('思考.started', core.getTime())
    thisExp_c.addData('思考.started', core.getTime())

    # Keep track of components for routine
    思考Components = [intro_parents1, intro_children1]
    for thisComponent in 思考Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED

    # --- Run Routine "思考" ---
    while continueRoutine and routineTimer.getTime() < 10.0:
        # Get current time
        tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
        tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = core.getTime()

        # Display "请认真思考" on win1
        if intro_parents1.status == NOT_STARTED and tThisFlip1 >= 0.0:
            intro_parents1.tStart = tThisFlipGlobal
            intro_parents1.setAutoDraw(True)
        if intro_parents1.status == STARTED and tThisFlipGlobal > intro_parents1.tStart + 10.0:
            intro_parents1.setAutoDraw(False)

        # Display "请认真思考" on win2
        if intro_children1.status == NOT_STARTED and tThisFlip2 >= 0.0:
            intro_children1.tStart = tThisFlipGlobal
            intro_children1.setAutoDraw(True)
        if intro_children1.status == STARTED and tThisFlipGlobal > intro_children1.tStart + 10.0:
            intro_children1.setAutoDraw(False)

        # Check for quit (typically the Esc key)
        if event.getKeys(keyList=["escape"]):
            core.quit()

        # Refresh the screen
        if continueRoutine:
            win1.flip()
            win2.flip()

    # --- Ending Routine "思考" ---
    for thisComponent in 思考Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)

    # Record the stop time for both p and c
    thisExp_p.addData('思考.stopped', core.getTime())
    thisExp_c.addData('思考.stopped', core.getTime())

    # Finalize and save the data entries for both experiment
    thisExp_p.nextEntry()
    thisExp_c.nextEntry()

# Close windows and quit
win1.close()
win2.close()
core.quit()