#!/usr/bin/env python
# -*- coding: utf-8 -*-

# --- Import packages ---
# --- Import packages ---
# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard
import random
import pandas as pd



# --- Setup global variables (available in all functions) ---
deviceManager = hardware.DeviceManager()
_thisDir = os.path.dirname(os.path.abspath(__file__))
expName = '指导语部分2'
psychopyVersion = '2024.1.5'


# Information about this experiment
expInfo = {
    'participant': '',
    'block': '',
    'date': data.getDateStr(),
    'expName': expName,
    'psychopyVersion': psychopyVersion,
}

# Window settings
PILOTING = core.setPilotModeFromArgs()
_fullScr = False
_winSize = [1470, 956]
_loggingLevel = logging.WARNING

# --- Functions ---
def showExpInfoDlg(expInfo):
    dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True)
    if not dlg.OK:
        core.quit()
    return expInfo

def setupData(expInfo, dataDir=None):
    """
    Make two ExperimentHandlers to handle trials and saving for both parents and children.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    
    Returns
    ==========
    tuple
        Two ExperimentHandlers for parents and children.
    """
    # Remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # Set data directory
    if dataDir is None:
        dataDir = _thisDir
    
    # Define filenames for parents and children
    filename_p = u'data/%s_%s_%s_parents' % (expInfo['participant'], expName, expInfo['date'])
    filename_c = u'data/%s_%s_%s_children' % (expInfo['participant'], expName, expInfo['date'])

    # Ensure filenames are relative to dataDir
    if os.path.isabs(filename_p):
        dataDir = os.path.commonprefix([dataDir, filename_p])
        filename_p = os.path.relpath(filename_p, dataDir)
    
    if os.path.isabs(filename_c):
        dataDir = os.path.commonprefix([dataDir, filename_c])
        filename_c = os.path.relpath(filename_c, dataDir)
    
    # Create an ExperimentHandler for parents
    thisExp_p = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='H:\\未命名文件夹\\指导语部分2.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename_p, sortColumns='time'
    )
    thisExp_p.setPriority('thisRow.t', priority.CRITICAL)
    thisExp_p.setPriority('expName', priority.LOW)
    
    # Create an ExperimentHandler for children
    thisExp_c = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='H:\\未命名文件夹\\指导语部分2.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename_c, sortColumns='time'
    )
    thisExp_c.setPriority('thisRow.t', priority.CRITICAL)
    thisExp_c.setPriority('expName', priority.LOW)
    
    # Return both ExperimentHandlers
    return thisExp_p, thisExp_c


def setupLogging(filename):
    logging.console.setLevel(_loggingLevel)
    logFile = logging.LogFile(filename + '.log', level=_loggingLevel)
    return logFile



def setupWindow(expInfo=None):
    win1 = visual.Window(size=_winSize, fullscr=_fullScr, screen=1, units='height')
    win2 = visual.Window(size=_winSize, fullscr=_fullScr, screen=2, units='height')
      # Activate windows to bring them into focus
    win1.winHandle.activate()
    win2.winHandle.activate()
    if expInfo and win1._monitorFrameRate is None:
        win1.getActualFrameRate(infoMsg='Measuring frame rate...')
        expInfo['frameRate'] = win1._monitorFrameRate
    win1.mouseVisible = True
    win2.mouseVisible = True
    return win1, win2

def setupDevices(expInfo, thisExp, win1, win2):
    """
    Setup the available input devices (e.g., keyboard) and add them to the device manager.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win1, win2 : psychopy.visual.Window
        Windows in which to run this experiment.
    
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # Setup input devices
    ioConfig = {'Keyboard': dict(use_keymap='psychopy')}
    
    # Launch ioHub server
    ioServer = io.launchHubServer(window=win1, **ioConfig)
    deviceManager.ioServer = ioServer

    # Initialize a single keyboard device
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    if deviceManager.getDevice('key_intro_p') is None:
        # initialise key_intro_p
        key_intro_p = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_intro_p',
        )
    if deviceManager.getDevice('key_intro_c') is None:
        # initialise key_resp
        key_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_intro_c',
        )
    if deviceManager.getDevice('key_intro_p1') is None:
        # initialise key_resp
        key_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_intro_p1',
        )
    if deviceManager.getDevice('key_resp_win2') is None:
        # initialise key_resp
        key_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_win2',
        )

    return True


    
def pauseExperiment(thisExp_p, thisExp_c, win1, win2, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp_p : psychopy.data.ExperimentHandler
        Handler object for the parents' data.
    thisExp_c : psychopy.data.ExperimentHandler
        Handler object for the children's data.
    win1, win2 : psychopy.visual.Window
        Windows for displaying parents' and children's content.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # Check if either experiment is paused
    if thisExp_p.status != PAUSED and thisExp_c.status != PAUSED:
        return

    # Pause any playback components
    for comp in playbackComponents:
        comp.pause()

    # Prevent components from auto-drawing
    win1.stashAutoDraw()
    win2.stashAutoDraw()

    # Make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )

    # Loop while either experiment is paused
    while thisExp_p.status == PAUSED or thisExp_c.status == PAUSED:
        # Check for "escape" key to end experiment
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp_p.status = FINISHED
            thisExp_c.status = FINISHED
            endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
            break

        # Refresh both windows
        win1.flip()
        win2.flip()

    # If either experiment finished while paused, end both
    if thisExp_p.status == FINISHED or thisExp_c.status == FINISHED:
        endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)

    # Resume any playback components
    for comp in playbackComponents:
        comp.play()

    # Restore auto-drawing for both windows
    win1.retrieveAutoDraw()
    win2.retrieveAutoDraw()

    # Reset any timers
    for timer in timers:
        timer.reset()

def run(expInfo, thisExp_p, thisExp_c, win1, win2, globalClock=None, thisSession=None):
    thisExp_p.status = STARTED
    thisExp_c.status = STARTED
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename_p = thisExp_p.dataFileName
    filename_c = thisExp_c.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
        # Ensure globalClock is a core.Clock object
    if not isinstance(globalClock, core.Clock):
        globalClock = core.Clock()
    
    current_path = os.getcwd()
    
    #指导语
    intro_parents = visual.TextStim(win=win1, text='欢迎家长参加拼图小游戏！\n...', units='norm')
    key_intro_p = keyboard.Keyboard()
    intro_children = visual.TextStim(win=win2, text='欢迎小朋友加入拼图小游戏!\n...', units='norm')
    key_intro_c = keyboard.Keyboard()
    #注视点
    polygon = visual.ShapeStim(
        win=win1, name='polygon', vertices='cross',units='norm', 
        size=(0.05, 0.05),
        ori=0.0, pos=(0, 0), anchor='center',
        lineWidth=1.0,     colorSpace='rgb',  lineColor=[1.0000, -1.0000, -1.0000], fillColor=[1.0000, -1.0000, -1.0000],
        opacity=None, depth=0.0, interpolate=True)
    polygon_0 = visual.ShapeStim(
        win=win2, name='polygon_0', vertices='cross',units='norm', 
        size=(0.05, 0.05),
        ori=0.0, pos=(0, 0), anchor='center',
        lineWidth=1.0,     colorSpace='rgb',  lineColor=[1.0000, -1.0000, -1.0000], fillColor=[1.0000, -1.0000, -1.0000],
        opacity=None, depth=0.0, interpolate=True)
    #图片选择
    polygon_3 = visual.Rect(
        win=win1, name='polygon_3',units='norm', 
        width=(0.36, 0.36)[0], height=(0.36, 0.36)[1],
        ori=0.0, pos=[0,0], anchor='center',
        lineWidth=1.0,     colorSpace='rgb',  lineColor=[1.0000, -1.0000, -1.0000], fillColor=[0.0000, 0.0000, 0.0000],
        opacity=1.0, depth=-1.0, interpolate=True)
    # Initialize the image stimuli on win1
    image_stimuli = [
        visual.ImageStim(
            win=win1, name=f'image_{i+1}', units='norm',
            image='default.png', mask=None, anchor='center',
            ori=0.0, pos=pos, size=(0.35, 0.35),
            color=[1, 1, 1], colorSpace='rgb', opacity=None,
            flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-2-i
        )
        for i, pos in enumerate([(-0.6, 0), (0, 0), (0.6, 0)])  # Define positions for images
    ]

    # Initialize the fixation cross on win2
    polygon_6 = visual.ShapeStim(
        win=win2, name='polygon_6', vertices='cross', units='norm',
        size=(0.05, 0.05),
        ori=0.0, pos=(0, 0), anchor='center',
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=None, interpolate=True
    )
    #ITI
    polygon_iti_1 = visual.ShapeStim(
        win=win1, name='polygon_iti_1', vertices='cross', units='norm', 
        size=(0.05, 0.05), ori=0.0, pos=(0, 0), anchor='center',
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=1.0, depth=-1.0, interpolate=True
    )
    polygon_iti_2 = visual.ShapeStim(
        win=win2, name='polygon_iti_2', vertices='cross', units='norm', 
        size=(0.05, 0.05), ori=0.0, pos=(0, 0), anchor='center',
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=1.0, depth=-1.0, interpolate=True
    )
    #思考
    intro_parents1 = visual.TextStim(win=win1, text='', units='norm')
    intro_children1 = visual.TextStim(win=win2, text='', units='norm')
    # ITI for win1 (renamed to polygon_iti_3)
    polygon_iti_3 = visual.ShapeStim(
        win=win1, name='polygon_iti_3', vertices='cross', units='norm', 
        size=(0.05, 0.05), ori=0.0, pos=(0, 0), anchor='center',
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=1.0, depth=-1.0, interpolate=True
    )

    # ITI for win2 (renamed to polygon_iti_4)
    polygon_iti_4 = visual.ShapeStim(
        win=win2, name='polygon_iti_4', vertices='cross', units='norm', 
        size=(0.05, 0.05), ori=0.0, pos=(0, 0), anchor='center',
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor='white',
        opacity=1.0, depth=-1.0, interpolate=True
    )
    # --- Initialize components for Routine "元素选择" ---
    polygon_5_win1 = visual.Rect(
        win=win1, name='polygon_5_win1', units='norm',
        width=(1.5, 0.35)[0], height=(1.5, 0.35)[1],
        ori=0.0, pos=(0, 0.575), anchor='center',
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor=[0.0, 0.0, 0.0],
        opacity=None, depth=-1.0, interpolate=True)
    polygon_5_win2 = visual.Rect(
        win=win2, name='polygon_5_win2', units='norm',
        width=(1.5, 0.35)[0], height=(1.5, 0.35)[1],
        ori=0.0, pos=(0, 0.575), anchor='center',  # win2 中的矩形位于上面
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor=[0.0, 0.0, 0.0],
        opacity=None, depth=-1.0, interpolate=True)
    # 确保已选中的图片位置与矩形框一致
    # Initialize global variables for selected image paths4
    selected_image_paths = []  # 保存选择的图片路径
    selected_image_names = []  # 保存选择的图片名称
    # 初始化已选中的图片展示列表 - win1 和 win2
    selected_images_win1 = [
        visual.ImageStim(win=win1, units='norm', pos=(-0.6 + i * 0.3, 0.575), size=(0.3, 0.3), image=None, depth=-2.0)
        for i in range(4)
    ]
    selected_images_win2 = [
        visual.ImageStim(win=win2, units='norm', pos=(-0.6 + i * 0.3, 0.575), size=(0.3, 0.3), image=None, depth=-2.0)
        for i in range(4)
    ]
    image_4_win1 = visual.ImageStim(
        win=win1, name='image_4_win1', units='norm',
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.35, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-2.0)
    # 当前图片展示 - win2
    image_4_win2 = visual.ImageStim(
        win=win2, name='image_4_win2', units='norm',
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.35, 0.35),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-2.0)
    key_intro_p1 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "元素显示" ---
    # 初始化已选中的图片展示列表 - win1 和 win2
    polygon_7_win1 = visual.Rect(
        win=win1, name='polygon_7_win1', units='norm',
        width=(1.5, 0.35)[0], height=(1.5, 0.35)[1],
        ori=0.0, pos=(0, 0.575), anchor='center',
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor=[0.0, 0.0, 0.0],
        opacity=None, depth=-1.0, interpolate=True)
    polygon_7_win2 = visual.Rect(
        win=win2, name='polygon_7_win2', units='norm',
        width=(1.5, 0.35)[0], height=(1.5, 0.35)[1],
        ori=0.0, pos=(0, 0.575), anchor='center',  # win2 中的矩形位于上面
        lineWidth=1.0, colorSpace='rgb', lineColor='white', fillColor=[0.0, 0.0, 0.0],
        opacity=None, depth=-1.0, interpolate=True)
    previous_image_win1 = [
        visual.ImageStim(win=win1, units='norm', pos=(-0.6 + i * 0.3, 0.575), size=(0.3, 0.3), image=None, depth=-2.0)
        for i in range(4)
    ]
    previous_image_win2 = [
        visual.ImageStim(win=win2, units='norm', pos=(-0.6 + i * 0.3, 0.575), size=(0.3, 0.3), image=None, depth=-2.0)
        for i in range(4)
    ]
    image_5_win1 = visual.ImageStim(
        win=win1, name='image_5_win1', units='norm',
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.35, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-2.0)
    image_5_win2 = visual.ImageStim(
        win=win2, name='image_5_win2', units='norm',
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.35, 0.35),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-2.0)
    key_resp_win2 = keyboard.Keyboard()
    
    # --- Initialize components for Routine "图片选择2" ---
    selected_image_paths_2 = []  # 初始化一个空列表，用于存储图片选择2部分的图片路径
    selected_image_names_2 = []  # 用于存储 "图片选择2" 部分选择的图片名称
    # 初始化玩家 P 的图片组件 - win1 (家长窗口)
    image_11_p = visual.ImageStim(
        win=win1, name='image_11_p', units='norm',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(-0.6, 0), size=(0.3, 0.3),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-1.0)

    image_22_p = visual.ImageStim(
        win=win1, name='image_22_p', units='norm',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.3, 0.3),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-2.0)

    image_33_p = visual.ImageStim(
        win=win1, name='image_33_p', units='norm',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0.6, 0), size=(0.3, 0.3),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-3.0)
    # 初始化玩家 C 的图片组件 - win2 (孩子窗口)
    image_11_c = visual.ImageStim(
        win=win2, name='image_11_c', units='norm',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(-0.6, 0), size=(0.3, 0.3),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-1.0)
    image_22_c = visual.ImageStim(
        win=win2, name='image_22_c', units='norm',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.3, 0.3),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-2.0)

    image_33_c = visual.ImageStim(
        win=win2, name='image_33_c', units='norm',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0.6, 0), size=(0.3, 0.3),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-3.0)
    # 初始化按键响应组件 - 玩家 C (孩子窗口)，命名为 key_resp_c1
    key_resp_c1 = keyboard.Keyboard()
    #反馈
    image_111_win1 = visual.ImageStim(
        win=win1, name='image_111_win1', units='norm',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.3, 0.3),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-2.0)

    image_111_win2 = visual.ImageStim(
        win=win2, name='image_111_win2', units='norm',
        image=None, mask=None, anchor='center',
        ori=0.0, pos=(0, 0), size=(0.3, 0.3),
        color=[1, 1, 1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False, texRes=128.0, interpolate=True, depth=-3.0)
        
    #反馈2    
    image_feedback_win1 = visual.ImageStim(win=win1, name='image_feedback_win1', units='norm',
                                       image=None, pos=(0, 0), size=(0.5, 0.5), color=[1, 1, 1])
    image_feedback_win2 = visual.ImageStim(win=win2, name='image_feedback_win2', units='norm',
                                       image=None, pos=(0, 0), size=(0.5, 0.5), color=[1, 1, 1])


    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win1.flip()  # flip window to reset last flip timer
    win2.flip()
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "指导语" ---
    continueRoutine = True
    # Record the start time of the routine
    thisExp_p.addData('指导语.started', globalClock.getTime(format='float'))
    thisExp_c.addData('指导语.started', globalClock.getTime(format='float'))

    # create starting attributes for the keys
    key_intro_p.keys = []
    key_intro_p.rt = []
    _key_intro_p_allKeys = []
    
    key_intro_c.keys = []
    key_intro_c.rt = []
    _key_intro_c_allKeys = []
    
    # keep track of which components have finished
    指导语Components = [intro_parents, key_intro_p, intro_children, key_intro_c]
    for thisComponent in 指导语Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
            
    # reset timers
    t = 0
    _timeToFirstFrame = win1.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "指导语" ---
    while continueRoutine:
        # Get current time
        t = routineTimer.getTime()
        tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
        tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
        frameN += 1

        # Update/draw components on each frame
        # *intro_parents* updates (displayed on win1)
        if intro_parents.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
            intro_parents.frameNStart = frameN
            intro_parents.tStart = t
            intro_parents.tStartRefresh = tThisFlip1
            win1.timeOnFlip(intro_parents, 'tStartRefresh')
            thisExp_p.timestampOnFlip(win1, 'intro_parents.started')
            intro_parents.status = STARTED
            intro_parents.setAutoDraw(True)

        # *intro_children* updates (displayed on win2)
        if intro_children.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
            intro_children.frameNStart = frameN
            intro_children.tStart = t
            intro_children.tStartRefresh = tThisFlip2
            win2.timeOnFlip(intro_children, 'tStartRefresh')
            thisExp_c.timestampOnFlip(win2, 'intro_children.started')
            intro_children.status = STARTED
            intro_children.setAutoDraw(True)

        # *key_intro_p* updates (parents' response)
        if key_intro_p.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
            key_intro_p.frameNStart = frameN
            key_intro_p.tStart = t
            key_intro_p.tStartRefresh = tThisFlip1
            win1.timeOnFlip(key_intro_p, 'tStartRefresh')
            thisExp_p.timestampOnFlip(win1, 'key_intro_p.started')
            key_intro_p.status = STARTED
            win1.callOnFlip(key_intro_p.clock.reset)
            win1.callOnFlip(key_intro_p.clearEvents, eventType='keyboard')

        # *key_intro_c* updates (children's response)
        if key_intro_c.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
            key_intro_c.frameNStart = frameN
            key_intro_c.tStart = t
            key_intro_c.tStartRefresh = tThisFlip2
            win2.timeOnFlip(key_intro_c, 'tStartRefresh')
            thisExp_c.timestampOnFlip(win2, 'key_intro_c.started')
            key_intro_c.status = STARTED
            win2.callOnFlip(key_intro_c.clock.reset)
            win2.callOnFlip(key_intro_c.clearEvents, eventType='keyboard')
        
        # Check for key presses on the keyboard
        keys = defaultKeyboard.getKeys(keyList=['1', '2'], waitRelease=False)

        # Record keys: '1' for parents and '2' for children
        for key in keys:
            if key.name == '1' and not key_intro_p.keys:
                key_intro_p.keys = key.name
                key_intro_p.rt = key.rt
                thisExp_p.addData('key_intro_p.rt', key_intro_p.rt)

            if key.name == '2' and not key_intro_c.keys:
                key_intro_c.keys = key.name
                key_intro_c.rt = key.rt
                thisExp_c.addData('key_intro_c.rt', key_intro_c.rt)

        # Check if both required keys have been pressed
        if key_intro_p.keys and key_intro_c.keys:
            continueRoutine = False  # End routine when both keys are pressed

        # Check for quit (Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp_p.status = FINISHED
            thisExp_c.status = FINISHED
            endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
            break

        # Refresh the screen for both windows
        if continueRoutine:
            win1.flip()
            win2.flip()

    # --- Ending Routine "指导语" ---
    for component in 指导语Components:
        if hasattr(component, "setAutoDraw"):
            component.setAutoDraw(False)

    # Record the stop time for both files
    thisExp_p.addData('指导语.stopped', globalClock.getTime(format='float'))
    thisExp_c.addData('指导语.stopped', globalClock.getTime(format='float'))

    # Check for responses and record for both files
    if not key_intro_p.keys:
        key_intro_p.keys = None
    thisExp_p.addData('key_intro_p.keys', key_intro_p.keys)

    if not key_intro_c.keys:
        key_intro_c.keys = None
    thisExp_c.addData('key_intro_c.keys', key_intro_c.keys)

    thisExp_p.nextEntry()
    thisExp_c.nextEntry()

    routineTimer.reset()  # Reset the non-slip timer
    
    # --- Prepare to start Routine "注视点" ---
    continueRoutine = True
    routineForceEnded = False

    # Record the start time of the routine for both p and c
    thisExp_p.addData('注视点.started', globalClock.getTime(format='float'))
    thisExp_c.addData('注视点.started', globalClock.getTime(format='float'))

    # Keep track of components for routine
    注视点Components = [polygon, polygon_0]

    for component in 注视点Components:
        component.tStart = None
        component.tStop = None
        component.tStartRefresh = None
        component.tStopRefresh = None
        if hasattr(component, 'status'):
            component.status = NOT_STARTED

    # Reset timers
    t = 0
    _timeToFirstFrame = win1.getFutureFlipTime(clock="now")
    _timeToFirstFrame2 = win2.getFutureFlipTime(clock="now")
    frameN = -1

    # --- Run Routine "注视点" ---
    while continueRoutine and routineTimer.getTime() < 1.5:
        # Get current time
        t = routineTimer.getTime()
        tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
        tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
        frameN += 1

        # Display the fixation cross on win1
        if polygon.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
            polygon.frameNStart = frameN
            polygon.tStart = t
            polygon.tStartRefresh = tThisFlipGlobal
            win1.timeOnFlip(polygon, 'tStartRefresh')
            thisExp_p.timestampOnFlip(win1, 'polygon.started')
            polygon.status = STARTED
            polygon.setAutoDraw(True)

        # Display the fixation cross on win2 (polygon_0)
        if polygon_0.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
            polygon_0.frameNStart = frameN
            polygon_0.tStart = t
            polygon_0.tStartRefresh = tThisFlipGlobal
            win2.timeOnFlip(polygon_0, 'tStartRefresh')
            thisExp_c.timestampOnFlip(win2, 'polygon_0.started')
            polygon_0.status = STARTED
            polygon_0.setAutoDraw(True)
    
        # Check for stop condition (after 1.5 seconds)
        if polygon.status == STARTED:
            if tThisFlipGlobal > polygon.tStartRefresh + 1.5 - frameTolerance:
                polygon.tStop = t
                polygon.tStopRefresh = tThisFlipGlobal
                polygon.frameNStop = frameN
                thisExp_p.timestampOnFlip(win1, 'polygon.stopped')
                polygon.status = FINISHED
                polygon.setAutoDraw(False)
        if polygon_0.status == STARTED:
            if tThisFlipGlobal > polygon_0.tStartRefresh + 1.5 - frameTolerance:
                polygon_0.tStop = t
                polygon_0.tStopRefresh = tThisFlipGlobal
                polygon_0.frameNStop = frameN
                thisExp_c.timestampOnFlip(win2, 'polygon_0.stopped')
                polygon_0.status = FINISHED
                polygon_0.setAutoDraw(False)
    
        # Check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp_p.status = FINISHED
            thisExp_c.status = FINISHED
            endExperiment(thisExp_p, win1=win1)
            endExperiment(thisExp_c, win2=win2)
            return

        # Refresh the screen
        if continueRoutine:
            win1.flip()
            win2.flip()

    # --- Ending Routine "注视点" ---
    polygon.setAutoDraw(False)
    polygon_0.setAutoDraw(False)

    # Record the stop time for both p and c
    thisExp_p.addData('注视点.stopped', globalClock.getTime(format='float'))
    thisExp_c.addData('注视点.stopped', globalClock.getTime(format='float'))

    # Using non-slip timing so subtract the expected duration of this Routine
    routineTimer.reset()
    thisExp_p.nextEntry()
    thisExp_c.nextEntry()

    # set up handler to look after randomisation of conditions etc
    trials_2 = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('mat1/object.xlsx'),
        seed=None, name='trials_2')
    # Add the loop to both experiment handlers
    thisExp_p.addLoop(trials_2)  # For 'parents' data
    thisExp_c.addLoop(trials_2)  # For 'children' data
    thisTrial_2 = trials_2.trialList[0] 
    if thisTrial_2 is not None:
        for paramName in thisTrial_2:
            globals()[paramName] = thisTrial_2[paramName]
    # Loop through trials
    for thisTrial_2 in trials_2:
        currentLoop = trials_2
        # Add a timestamp for both 'parents' and 'children' data
        thisExp_p.timestampOnFlip(win1, 'thisRow.t', format=globalClock.format)
        thisExp_c.timestampOnFlip(win2, 'thisRow.t', format=globalClock.format)
        # Pause the experiment if requested
        if thisExp_p.status == PAUSED or thisExp_c.status == PAUSED:
            pauseExperiment(thisExp=thisExp_p, win=win1, timers=[routineTimer], playbackComponents=[])
            pauseExperiment(thisExp=thisExp_c, win=win2, timers=[routineTimer], playbackComponents=[])
        if thisTrial_2 is not None:
            for paramName in thisTrial_2:
                globals()[paramName] = thisTrial_2[paramName] 
        # --- Prepare to start Routine "图片选择" ---
        continueRoutine = True
        # Record the start time of the routine for both p and c
        thisExp_p.addData('图片选择.started', globalClock.getTime(format='float'))
        thisExp_c.addData('图片选择.started', globalClock.getTime(format='float'))
        
        # --- Begin Routine: set up stimuli based on trial ---
        #object1 = trials_2.trialList[trials_2.thisN]['object1']
        #object2 = trials_2.trialList[trials_2.thisN]['object2']
        #object3 = trials_2.trialList[trials_2.thisN]['object3']
        # 设置例程中使用的刺激
        object1 = thisTrial_2['object1']
        object2 = thisTrial_2['object2']
        object3 = thisTrial_2['object3']

        # Construct full paths to the object images
        #object1 = current_path + '\\mat1' + '\\' + object1
        #object2 = current_path + '\\mat1' + '\\' + object2
        #object3 = current_path + '\\mat1' + '\\' + object3
        object1 = os.path.join(current_path, 'mat1', object1)
        object2 = os.path.join(current_path, 'mat1', object2)
        object3 = os.path.join(current_path, 'mat1', object3)

        # Set images for the stimuli
        image_stimuli[0].setImage(object1)
        image_stimuli[1].setImage(object2)
        image_stimuli[2].setImage(object3)

        # Set polygon opacity and position if needed based on the trial condition (e.g., `rim`)
        if rim == 4:
            pos = [-0.6, 0]
            op = 1
        elif rim == 5:
            pos = [0, 0]
            op = 1
        elif rim == 6:
            pos = [0.6, 0]
            op = 1

        polygon_3.setOpacity(op)
        polygon_3.setPos(pos)

        # Keep track of components for routine
        图片选择Components = [polygon_3] + image_stimuli + [polygon_6]
        for component in 图片选择Components:
            component.tStart = None
            component.tStop = None
            component.tStartRefresh = None
            component.tStopRefresh = None
            if hasattr(component, 'status'):
                component.status = NOT_STARTED
        # Reset timers
        t = 0
        _timeToFirstFrame = win1.getFutureFlipTime(clock="now")
        frameN = -1
        # --- Run Routine "图片选择" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 3.0:
        # Get current time
            t = routineTimer.getTime()
            tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
            tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
            frameN += 1
            # Display the rectangle on win1
            if polygon_3.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                polygon_3.frameNStart = frameN
                polygon_3.tStart = t
                polygon_3.tStartRefresh = tThisFlipGlobal
                win1.timeOnFlip(polygon_3, 'tStartRefresh')
                thisExp_p.timestampOnFlip(win1, 'polygon_3.started')
                polygon_3.status = STARTED
                polygon_3.setAutoDraw(True)

            # Display the images on win1
            for image in image_stimuli:
                if image.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                    image.frameNStart = frameN
                    image.tStart = t
                    image.tStartRefresh = tThisFlipGlobal
                    win1.timeOnFlip(image, 'tStartRefresh')
                    thisExp_p.timestampOnFlip(win1, f'{image.name}.started')
                    image.status = STARTED
                    image.setAutoDraw(True)

            # Display the fixation cross on win2
            if polygon_6.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                polygon_6.frameNStart = frameN
                polygon_6.tStart = t
                polygon_6.tStartRefresh = tThisFlipGlobal
                win2.timeOnFlip(polygon_6, 'tStartRefresh')
                thisExp_c.timestampOnFlip(win2, 'polygon_6.started')
                polygon_6.status = STARTED
                polygon_6.setAutoDraw(True)

            # Check if the routine should stop (after 3.0 seconds)
                # 停止显示 Polygon_3 和图像
            if tThisFlipGlobal > polygon_3.tStartRefresh + 3.0 - frameTolerance:
                for image in image_stimuli:
                    if image.status == STARTED:
                        image.tStop = t
                        image.tStopRefresh = tThisFlipGlobal
                        image.frameNStop = frameN
                        thisExp_p.timestampOnFlip(win1, f'{image.name}.stopped')
                        image.status = FINISHED
                        image.setAutoDraw(False)
                if polygon_3.status == STARTED:
                    polygon_3.tStop = t
                    polygon_3.tStopRefresh = tThisFlipGlobal
                    polygon_3.frameNStop = frameN
                    thisExp_p.timestampOnFlip(win1, 'polygon_3.stopped')
                    polygon_3.status = FINISHED
                    polygon_3.setAutoDraw(False)
                if polygon_6.status == STARTED:
                    polygon_6.tStop = t
                    polygon_6.tStopRefresh = tThisFlipGlobal
                    polygon_6.frameNStop = frameN
                    thisExp_c.timestampOnFlip(win2, 'polygon_6.stopped')
                    polygon_6.status = FINISHED
                    polygon_6.setAutoDraw(False)
                continueRoutine = False  # 结束例程
            # Check for quit (Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp_p.status = FINISHED
                thisExp_c.status = FINISHED
                endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                return
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in 图片选择Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished

            # Refresh the screen for both win1 and win2
            if continueRoutine:
                win1.flip()
                win2.flip()


        # --- Ending Routine "图片选择" ---
        for component in 图片选择Components:
            if hasattr(component, "setAutoDraw"):
                component.setAutoDraw(False)

        # Record the stop time for both p and c
        thisExp_p.addData('图片选择.stopped', globalClock.getTime(format='float'))
        thisExp_c.addData('图片选择.stopped', globalClock.getTime(format='float'))
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-3.000000)
        
        # --- Prepare to start Routine "ITI" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp_p.addData('ITI.started', globalClock.getTime(format='float'))
        thisExp_c.addData('ITI.started', globalClock.getTime(format='float'))

        # Run 'Begin Routine' code from code
        iti_tim = random.randrange(900, 1100, 1)
        ITI_time = iti_tim / 1000

        # keep track of which components have finished
        # Track the components for ITI
        ITIComponents = [polygon_iti_1, polygon_iti_2]
        for thisComponent in ITIComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED

        # reset timers
        t = 0
        _timeToFirstFrame1 = win1.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "ITI" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
            tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
            frameN += 1  # num
                # Display the fixation cross on win1
            if polygon_iti_1.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                polygon_iti_1.frameNStart = frameN
                polygon_iti_1.tStart = t
                polygon_iti_1.tStartRefresh = tThisFlipGlobal
                win1.timeOnFlip(polygon_iti_1, 'tStartRefresh')
                thisExp_p.timestampOnFlip(win1, 'polygon_iti_1.started')
                polygon_iti_1.status = STARTED
                polygon_iti_1.setAutoDraw(True)
            # Display the fixation cross on win2 (polygon_iti_2)
            if polygon_iti_2.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                polygon_iti_2.frameNStart = frameN
                polygon_iti_2.tStart = t
                polygon_iti_2.tStartRefresh = tThisFlipGlobal
                win2.timeOnFlip(polygon_iti_2, 'tStartRefresh')
                thisExp_c.timestampOnFlip(win2, 'polygon_iti_2.started')
                polygon_iti_2.status = STARTED
                polygon_iti_2.setAutoDraw(True)
                # Stop drawing after the ITI duration (for both win1 and win2)
            if polygon_iti_1.status == STARTED:
                if polygon_iti_1.tStartRefresh is not None and tThisFlipGlobal > polygon_iti_1.tStartRefresh + ITI_time - frameTolerance:
                    polygon_iti_1.tStop = t
                    polygon_iti_1.tStopRefresh = tThisFlipGlobal
                    polygon_iti_1.frameNStop = frameN
                    thisExp_p.timestampOnFlip(win1, 'polygon_iti_1.stopped')
                    polygon_iti_1.status = FINISHED
                    polygon_iti_1.setAutoDraw(False)
            if polygon_iti_2.status == STARTED:
                if polygon_iti_2.tStartRefresh is not None and tThisFlipGlobal > polygon_iti_2.tStartRefresh + ITI_time - frameTolerance:
                    polygon_iti_2.tStop = t
                    polygon_iti_2.tStopRefresh = tThisFlipGlobal
                    polygon_iti_2.frameNStop = frameN
                    thisExp_c.timestampOnFlip(win2, 'polygon_iti_2.stopped')
                    polygon_iti_2.status = FINISHED
                    polygon_iti_2.setAutoDraw(False)
                
    
            # Check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp_p.status = FINISHED
                thisExp_c.status = FINISHED
                endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                return

            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ITIComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # Refresh the screen
            if continueRoutine:
                win1.flip()
                win2.flip()
                
        # --- Ending Routine "ITI" ---
        for thisComponent in ITIComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # Record the stop time for both p and 
        thisExp_p.addData('ITI.stopped', globalClock.getTime(format='float'))
        thisExp_c.addData('ITI.stopped', globalClock.getTime(format='float'))
        # Reset the non-slip timer
        routineTimer.reset()

        # --- Prepare to start Routine "思考" ---
        continueRoutine = True
        #routineForceEnded = False
        # Record the start time of the routine for both p and c
        thisExp_p.addData('思考.started', globalClock.getTime(format='float'))
        thisExp_c.addData('思考.started', globalClock.getTime(format='float'))
        
        intro_parents1.setText('请认真思考')
        intro_children1.setText('请认真思考')
        

        # Keep track of components for routine
        思考Components = [intro_parents1, intro_children1]
        for thisComponent in 思考Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED

        # Reset timers
        t = 0
        _timeToFirstFrame = win1.getFutureFlipTime(clock="now")
        frameN = -1
        # --- Run Routine "思考" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 10.0:
            # Get current time
            t = routineTimer.getTime()
            tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
            tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
            frameN += 1

            # Display "请认真思考" on win1
            if intro_parents1.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                intro_parents1.frameNStart = frameN
                intro_parents1.tStart = t
                intro_parents1.tStartRefresh = tThisFlipGlobal
                win1.timeOnFlip(intro_parents1, 'tStartRefresh')
                thisExp_p.timestampOnFlip(win1, 'intro_parents1.started')
                intro_parents1.status = STARTED
                intro_parents1.setAutoDraw(True)

            # Display "请认真思考" on win2
            if intro_children1.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                intro_children1.frameNStart = frameN
                intro_children1.tStart = t
                intro_children1.tStartRefresh = tThisFlipGlobal
                win2.timeOnFlip(intro_children1, 'tStartRefresh')
                thisExp_c.timestampOnFlip(win2, 'intro_children1.started')
                intro_children1.status = STARTED
                intro_children1.setAutoDraw(True)

            # Stop displaying after 10 seconds
            if intro_parents1.status == STARTED:
                if tThisFlipGlobal > intro_parents1.tStartRefresh + 10.0 - frameTolerance:
                    intro_parents1.tStop = t
                    intro_parents1.tStopRefresh = tThisFlipGlobal
                    intro_parents1.frameNStop = frameN
                    thisExp_p.timestampOnFlip(win1, 'intro_parents1.stopped')
                    intro_parents1.status = FINISHED
                    intro_parents1.setAutoDraw(False)
            if intro_children1.status == STARTED:
                if tThisFlipGlobal > intro_children1.tStartRefresh + 10.0 - frameTolerance:
                    intro_children1.tStop = t
                    intro_children1.tStopRefresh = tThisFlipGlobal
                    intro_children1.frameNStop = frameN
                    thisExp_c.timestampOnFlip(win2, 'intro_children1.stopped')
                    intro_children1.status = FINISHED
                    intro_children1.setAutoDraw(False)
            # Check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp_p.status = FINISHED
                thisExp_c.status = FINISHED
                endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                return

            # Refresh the screen
            if continueRoutine:
                win1.flip()
                win2.flip()
        # --- Ending Routine "思考" ---
        for thisComponent in 思考Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)

        # Record the stop time for both p and c
        thisExp_p.addData('思考.stopped', globalClock.getTime(format='float'))
        thisExp_c.addData('思考.stopped', globalClock.getTime(format='float'))
        
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-10.000000)

        # Set up handler to look after randomisation of conditions etc.
        trials = data.TrialHandler(nReps=1.0, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('mat1/feature.xlsx'),
            seed=None, name='trials')
        # Add the loop to both experiment handlers
        thisExp_p.addLoop(trials)  # For 'parents' data (win1)
        thisExp_c.addLoop(trials)  # For 'children' data (win2)
        thisTrial = trials.trialList[0]
        # Abbreviate parameter names if possible (e.g., rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                globals()[paramName] = thisTrial[paramName]
        # 初始化已选择的图片列表
        win1_selected_images = []  # 用于记录 win1 上选择的图片
        win2_displayed_images = []  # 用于记录 win2 上展示的图片
        max_elements = 4  # 最多选择 4 个元素
        for thisTrial in trials:
            if len(win1_selected_images) >= max_elements:
                trials.finished = True  # 如果选择次数已达 4 次，结束循环
                break
            # 为 win1 记录时间戳
            thisExp_p.timestampOnFlip(win1, 'thisRow.t_win1', format=globalClock.format)
            # Record a timestamp for win2 and save it to the 'children' experiment handler
            thisExp_c.timestampOnFlip(win2, 'thisRow.t_win2', format=globalClock.format)

            # pause experiment here if requested
            if thisExp_p.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp_p,
                    win=win1,
                    timers=[routineTimer],
                    playbackComponents=[]
                )
            if thisExp_c.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp_c,
                    win=win2,
                    timers=[routineTimer],
                    playbackComponents=[]
                )
            # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
            if thisTrial is not None:
                for paramName in thisTrial:
                    globals()[paramName] = thisTrial[paramName]
                    
            
            # --- Prepare to start Routine "ITI" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp_p.addData('ITI_3.started', globalClock.getTime(format='float'))
            thisExp_c.addData('ITI_4.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code
            iti_tim = random.randrange(900, 1100, 1)
            ITI_time = iti_tim / 1000
            # keep track of which components have finished
            ITIComponents = [polygon_iti_3, polygon_iti_4]
            for thisComponent in ITIComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame1 = win1.getFutureFlipTime(clock="now")
            _timeToFirstFrame2 = win2.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "ITI" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
                tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of com
                # *polygon_iti_3* updates (win1)
                if polygon_iti_3.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                    # keep track of start time/frame for later
                    polygon_iti_3.frameNStart = frameN  # exact frame index
                    polygon_iti_3.tStart = t  # local t and not account for scr refresh
                    polygon_iti_3.tStartRefresh = tThisFlipGlobal  # on global time
                    win1.timeOnFlip(polygon_iti_3, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp_p.timestampOnFlip(win1, 'polygon_iti_3.started')
                    # update status
                    polygon_iti_3.status = STARTED
                    polygon_iti_3.setAutoDraw(True)
                # *polygon_iti_4* updates (win2)
                if polygon_iti_4.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                    # keep track of start time/frame for later
                    polygon_iti_4.frameNStart = frameN  # exact frame index
                    polygon_iti_4.tStart = t  # local t and not account for scr refresh
                    polygon_iti_4.tStartRefresh = tThisFlipGlobal  # on global time
                    win2.timeOnFlip(polygon_iti_4, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp_c.timestampOnFlip(win2, 'polygon_iti_4.started')
                    # update status
                    polygon_iti_4.status = STARTED
                    polygon_iti_4.setAutoDraw(True)
                # if polygon_iti_3 and polygon_iti_4 are stopping this frame
                if polygon_iti_3.status == STARTED and tThisFlipGlobal > polygon_iti_3.tStartRefresh + ITI_time - frameTolerance:
                    # keep track of stop time/frame for later
                    polygon_iti_3.tStop = t  # not accounting for scr refresh
                    polygon_iti_3.tStopRefresh = tThisFlipGlobal  # on global time
                    polygon_iti_3.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp_p.timestampOnFlip(win1, 'polygon_iti_3.stopped')
                    # update status
                    polygon_iti_3.status = FINISHED
                    polygon_iti_3.setAutoDraw(False)
                if polygon_iti_4.status == STARTED and tThisFlipGlobal > polygon_iti_4.tStartRefresh + ITI_time - frameTolerance:
                    # keep track of stop time/frame for later
                    polygon_iti_4.tStop = t  # not accounting for scr refresh
                    polygon_iti_4.tStopRefresh = tThisFlipGlobal  # on global time
                    polygon_iti_4.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp_c.timestampOnFlip(win2, 'polygon_iti_4.stopped')
                    # update status
                    polygon_iti_4.status = FINISHED
                    polygon_iti_4.setAutoDraw(False)
                    
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp_p.status = FINISHED
                    thisExp_c.status = FINISHED
                    endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                    return
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in ITIComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
            
                # Refresh the screen
                if continueRoutine:
                    win1.flip()
                    win2.flip()
            # --- Ending Routine "ITI" ---
            for thisComponent in ITIComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # Record the stop time for both ITI components
            thisExp_p.addData('ITI_3.stopped', globalClock.getTime(format='float'))
            thisExp_c.addData('ITI_4.stopped', globalClock.getTime(format='float'))
            # Reset the non-slip timer
            routineTimer.reset()
            # --- Prepare to start Routine "元素选择" ---
            continueRoutine = True
            skip_routine2 = False  # 用于决定是否跳过 "元素展示" 部分
            win1_selected_count = 0  # 记录选择次数
            # Set up the current trial feature to display
            #features = thisTrial['feature']
            #features = os.path.join(current_path, 'mat1', features)
            #image_4_win1.setImage(features)
            # 获取 feature 路径
            features = thisTrial.get('feature', None)  # 使用 get 方法以防止 'feature' 键不存在
            if features:
                # 如果 features 不为 None，则拼接路径
                features = os.path.join(current_path, 'mat1', features)
                image_4_win1.setImage(features)
            else:
                print("Warning: 'feature' value is None. Skipping this trial.")
                continue  # 跳过当前循环，继续下一个 trial
                            # update component parameters for each repeat
            thisExp_p.addData('元素选择.started', globalClock.getTime(format='float'))
            thisExp_c.addData('元素选择.started', globalClock.getTime(format='float'))
            # 始终显示 win1 和 win2 上的矩形框
            polygon_5_win1.setAutoDraw(True)
            polygon_5_win2.setAutoDraw(True)
            # 如果已经有选择的图片，展示这些图片
            if len(win1_selected_images) > 0:
                # 在 win1 上显示已选择的图片
                for idx, img in enumerate(win1_selected_images):
                    selected_images_win1[idx].setImage(img)
                    selected_images_win1[idx].setAutoDraw(True)
                    # 在 win2 上显示已选择的图
                for idx, img in enumerate(win2_displayed_images):
                    selected_images_win2[idx].setImage(img)
                    selected_images_win2[idx].setAutoDraw(True)

            
            # 初始化按键响应
            key_intro_p1.keys = []
            key_intro_p1.rt = []
            _key_intro_p1_allKeys = []
            # 设置组件列表
            元素选择Components = [polygon_5_win1, image_4_win1, polygon_5_win2, key_intro_p1]+ selected_images_win1 + selected_images_win2
            for thisComponent in 元素选择Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # 重置计时器
            t = 0
            _timeToFirstFrame1 = win1.getFutureFlipTime(clock="now")
            _timeToFirstFrame2 = win2.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "元素选择" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # 获取当前时间
                t = routineTimer.getTime()
                tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
                tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
                frameN += 1  # 记录完成的帧数
                # 更新并绘制 image_4_win1 (feature 图片)
                if image_4_win1.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                    image_4_win1.frameNStart = frameN  # 记录起始帧
                    image_4_win1.tStart = t  # 记录本地起始时间
                    image_4_win1.tStartRefresh = tThisFlipGlobal  # 记录全局起始时间
                    win1.timeOnFlip(image_4_win1, 'tStartRefresh')  # 下一次屏幕刷新时记录时间
                    thisExp_p.timestampOnFlip(win1, 'image_4_win1.started')
                    image_4_win1.status = STARTED
                    image_4_win1.setAutoDraw(True)
                # 如果 image_4_win1 是活动的，检查是否需要停止
                if image_4_win1.status == STARTED:
                    if key_intro_p1.keys:  # 如果有按键响应
                        image_4_win1.tStop = t  # 记录本地结束时间
                        image_4_win1.frameNStop = frameN  # 记录结束帧数
                        thisExp_p.timestampOnFlip(win1, 'image_4_win1.stopped')
                        image_4_win1.setAutoDraw(False)  # 停止绘制 image_4_win1
                        image_4_win1.status = FINISHED
                # 更新并绘制按键响应 (key_intro_p1)
                waitOnFlip = False
                if key_intro_p1.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                    key_intro_p1.frameNStart = frameN  # 记录起始帧
                    key_intro_p1.tStart = t  # 记录本地起始时间
                    key_intro_p1.tStartRefresh = tThisFlipGlobal  # 记录全局起始时间
                    win1.timeOnFlip(key_intro_p1, 'tStartRefresh')  # 下一次屏幕刷新时记录时间
                    thisExp_p.timestampOnFlip(win1, 'key_intro_p1.started')
                    key_intro_p1.status = STARTED
                    waitOnFlip = True
                    win1.callOnFlip(key_intro_p1.clock.reset)  # 在下一次屏幕刷新时将计时器重置
                    win1.callOnFlip(key_intro_p1.clearEvents, eventType='keyboard')  # 在下一次屏幕刷新时清除按键事件
                # 检查按键响应 (key_intro_p1)
                if key_intro_p1.status == STARTED and not waitOnFlip:
                    theseKeys = key_intro_p1.getKeys(keyList=['1', '2'], waitRelease=False)
                    _key_intro_p1_allKeys.extend(theseKeys)
                    if len(_key_intro_p1_allKeys):
                        key_intro_p1.keys = _key_intro_p1_allKeys[-1].name
                        key_intro_p1.rt = _key_intro_p1_allKeys[-1].rt
                        key_intro_p1.duration = _key_intro_p1_allKeys[-1].duration
                        # 结束按键组件
                        key_intro_p1.tStop = t  # 记录本地结束时间
                        key_intro_p1.frameNStop = frameN  # 记录结束帧数
                        thisExp_p.timestampOnFlip(win1, 'key_intro_p1.stopped')
                        key_intro_p1.status = FINISHED
                        continueRoutine = False  # 当检测到按键时，停止例程以继续执行后续逻辑
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp_p.status = FINISHED
                    thisExp_c.status = FINISHED
                    endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                    return
                # 检查是否所有组件都完成
                if not continueRoutine:  # 如果有组件请求结束例程，则强制结束
                    routineForceEnded = True
                    break
                continueRoutine = False  # 如果至少有一个组件还未完成，则继续
                for thisComponent in 元素选择Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break
                # 刷新屏幕
                if continueRoutine:
                    win1.flip()
                    win2.flip()
            # --- Ending Routine "元素选择" ---
            for thisComponent in 元素选择Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # 保存按键响应数据
            # 保存已选择的图片到 Excel
            selected_data = pd.DataFrame({'selected_image_paths': selected_image_paths})
            selected_data.to_excel(os.path.join(current_path, 'selected_images.xlsx'), index=False)
            thisExp_p.addData('key_intro_p1.keys', key_intro_p1.keys)
            thisExp_p.addData('key_intro_p1.rt', key_intro_p1.rt)
            thisExp_p.addData('key_intro_p1.duration', key_intro_p1.duration)
            
            # 处理按键 `1` 和 `2` 的响应逻辑
            if key_intro_p1.keys == '1':
                # 将 feature 添加到已选择图片列表
                # 设置当前 trial 中的 feature
                features = thisTrial['feature']
                feature_path = os.path.join(current_path, 'mat1', features)
                win1_selected_images.append(feature_path)
                win2_displayed_images.append(feature_path)
                win1_selected_count += 1
                skip_routine2 = False
                # 保存所选图片的路径和名称到全局列表中
                selected_image_paths.append(feature_path)  # 保存图片路径
                selected_image_names.append(os.path.basename(feature_path))  # 保存图片名称
                
            elif key_intro_p1.keys == '2':
                # 跳过元素展示，直接进入下一个 ITI
                skip_routine2 = True
                
            # --- Prepare to start Routine "元素展示" ---
            if skip_routine2:
                continueRoutine = False  # 如果需要跳过，直接跳过 routine2
            else:
                continueRoutine = True  # 如果不跳过，则继续运行 routine2
            # update component parameters for each repeat
            thisExp_p.addData('元素展示.started', globalClock.getTime(format='float'))
            thisExp_c.addData('元素展示.started', globalClock.getTime(format='float'))
            # 确保矩形框先绘制，再绘制图片
            polygon_7_win1.setAutoDraw(True)
            polygon_7_win2.setAutoDraw(True)
            current_image_position = (0.0, 0.0)  # 当前选择图片的 win1 位置
            current_image_position_win2 = (0.0, 0.0)  # 当前选择图片的 win2 位置
            
            # 设置之前选择的图片在 win1 和 win2 上的矩形框中
            # 如果已经有选择的图片，展示这些图片
            if len(win1_selected_images) > 0:
                # 在 win1 上显示已选择的图片
                for idx, img in enumerate(win1_selected_images):
                    previous_image_win1[idx].setImage(img)
                    previous_image_win1[idx].setAutoDraw(True)
                    # 在 win2 上显示已选择的图
                for idx, img in enumerate(win2_displayed_images):
                    previous_image_win2[idx].setImage(img)
                    previous_image_win2[idx].setAutoDraw(True)

                  # 显示当前选择的图片（仅在特定位置）
            current_image_path = selected_image_paths[-1] if selected_image_paths else None
            if current_image_path:
                image_5_win1.setPos(current_image_position)
                image_5_win1.setImage(current_image_path)
                image_5_win1.setAutoDraw(True)

                image_5_win2.setPos(current_image_position_win2)
                image_5_win2.setImage(current_image_path)
                image_5_win2.setAutoDraw(True)

           
            # 初始化按键响应组件
            key_resp_win2.keys = []
            key_resp_win2.rt = []
            _key_resp_win2_allKeys = []
            
            # keep track of which components have finished
            元素展示Components = [polygon_7_win1, image_5_win1, polygon_7_win2, image_5_win2, key_resp_win2]+previous_image_win1+previous_image_win2
            for thisComponent in 元素展示Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
                    
            # reset timers
            t = 0
            _timeToFirstFrame1 = win1.getFutureFlipTime(clock="now")
            _timeToFirstFrame2 = win2.getFutureFlipTime(clock="now")
            frameN = -1
            # --- Run Routine "元素展示" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # 获取当前时间
                t = routineTimer.getTime()
                tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
                tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
                frameN += 1  # 记录完成的帧数
                
                # --- 更新并绘制组件 ---
                # 更新并绘制 polygon_7_win1 (矩形框)
                if polygon_7_win1.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                    polygon_7_win1.frameNStart = frameN  # 记录起始帧
                    polygon_7_win1.tStart = t  # 记录本地起始时间
                    polygon_7_win1.tStartRefresh = tThisFlipGlobal  # 记录全局起始时间
                    win1.timeOnFlip(polygon_7_win1, 'tStartRefresh')  # 下一次屏幕刷新时记录时间
                    thisExp_p.timestampOnFlip(win1, 'polygon_7_win1.started')
                    polygon_7_win1.status = STARTED
                # 如果 polygon_7_win1 是活动的，检查是否需要停止
                if polygon_7_win1.status == STARTED:
                    if key_resp_win2.keys:  # 假设在检测到按键响应后停止
                        polygon_7_win1.tStop = t  # 记录本地结束时间
                        polygon_7_win1.frameNStop = frameN  # 记录结束帧数
                        thisExp_p.timestampOnFlip(win1, 'polygon_7_win1.stopped')
                        polygon_7_win1.setAutoDraw(False)  # 停止绘制
                        polygon_7_win1.status = FINISHED
                # 更新并绘制 polygon_7_win2 (矩形框)
                if polygon_7_win2.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                    polygon_7_win2.frameNStart = frameN  # 记录起始帧
                    polygon_7_win2.tStart = t  # 记录本地起始时间
                    polygon_7_win2.tStartRefresh = tThisFlipGlobal  # 记录全局起始时间
                    win2.timeOnFlip(polygon_7_win2, 'tStartRefresh')  # 下一次屏幕刷新时记录时间
                    thisExp_c.timestampOnFlip(win2, 'polygon_7_win2.started')
                    polygon_7_win2.status = STARTED
                if polygon_7_win2.status == STARTED:
                    if key_resp_win2.keys:  # 假设在检测到按键响应后停止
                        polygon_7_win2.tStop = t  # 记录本地结束时间
                        polygon_7_win2.frameNStop = frameN  # 记录结束帧数
                        thisExp_c.timestampOnFlip(win2, 'polygon_7_win2.stopped')
                        polygon_7_win2.setAutoDraw(False)  # 停止绘制
                        polygon_7_win2.status = FINISHED
                # *key_resp_win2* updates
                waitOnFlip = False
                if key_resp_win2.status == NOT_STARTED and tThisFlip2 >= 0.0-frameTolerance:
                    key_resp_win2.frameNStart = frameN  # exact frame index
                    key_resp_win2.tStart = t  # local t and not account for scr refresh
                    key_resp_win2.tStartRefresh = tThisFlipGlobal  # on global time
                    win2.timeOnFlip(key_resp_win2, 'tStartRefresh')  # time at next scr refresh
                    thisExp_c.timestampOnFlip(win2, 'key_resp_win2.started')
                    key_resp_win2.status = STARTED
                    waitOnFlip = True
                    win2.callOnFlip(key_resp_win2.clock.reset)  # t=0 on next screen flip
                    win2.callOnFlip(key_resp_win2.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_win2.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_win2.getKeys(keyList=['1', '2'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_win2_allKeys.extend(theseKeys)
                    if len(_key_resp_win2_allKeys):
                        key_resp_win2.keys = _key_resp_win2_allKeys[-1].name  # just the last key pressed
                        key_resp_win2.rt = _key_resp_win2_allKeys[-1].rt
                        key_resp_win2.duration = _key_resp_win2_allKeys[-1].duration
                        # 停止按键组件
                        key_resp_win2.tStop = t  # 记录本地结束时间
                        key_resp_win2.frameNStop = frameN  # 记录结束帧数
                        thisExp_c.timestampOnFlip(win2, 'key_resp_win2.stopped')
                        key_resp_win2.status = FINISHED
                        continueRoutine = False  
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp_p.status = FINISHED
                    thisExp_c.status = FINISHED
                if thisExp_p.status == FINISHED or thisExp_c.status == FINISHED or endExpNow:
                    endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                    return
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in 元素展示Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win1.flip()
                    win2.flip()
            # --- Ending Routine "元素展示" ---
            for thisComponent in 元素展示Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # Save key response from win2
            thisExp_p.addData('元素展示.stopped', globalClock.getTime(format='float'))
            thisExp_c.addData('元素展示.stopped', globalClock.getTime(format='float'))
            
            if key_resp_win2.keys in ['', [], None]:
                key_resp_win2.keys = None
            thisExp_c.addData('key_resp_win2.keys', key_resp_win2.keys)
            if key_resp_win2.keys == '1':
                # If key '1' is pressed, end the current trials loop
                trials.finished = True  # End the trials loop
                continueRoutine = False  # 确保当前例程结束，进入 "图片选择2" 部分
            elif key_resp_win2.keys == '2':
                continueRoutine = False  # Keep the current loop active
            thisExp_c.addData('key_resp_win2.rt', key_resp_win2.rt)
            # the Routine "元素展示" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp_p.nextEntry()
            thisExp_c.nextEntry()
            if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
                
                
        # --- Prepare to start Routine "图片选择2" ---
        expected_key = str(thisTrial_2['key'])   # 获取正确的按键
        if key_resp_win2.keys == '1':
            continueRoutine = True

        # update component parameters for each repeat
        thisExp_p.addData('图片选择2.started', globalClock.getTime(format='float'))
        thisExp_c.addData('图片选择2.started', globalClock.getTime(format='float'))
        # 设置例程中使用的刺激
        object1 = thisTrial_2['object1']
        object2 = thisTrial_2['object2']
        object3 = thisTrial_2['object3']
        object1 = os.path.join(current_path, 'mat1', object1)
        object2 = os.path.join(current_path, 'mat1', object2)
        object3 = os.path.join(current_path, 'mat1', object3)
        # Update the images for player 1 and player 2
        image_11_p.setImage(object1)
        image_22_p.setImage(object2)
        image_33_p.setImage(object3)
        image_11_c.setImage(object1)
        image_22_c.setImage(object2)
        image_33_c.setImage(object3)
        # create starting attributes for key_resp_2
        key_resp_c1.keys = []
        key_resp_c1.rt = []
        _key_resp_c1_allKeys = []

            
        # keep track of which components have finished
        图片选择2Components = [image_11_p, image_22_p, image_33_p, image_11_c, image_22_c, image_33_c, key_resp_c1]
        for thisComponent in 图片选择2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame1 = win1.getFutureFlipTime(clock="now")
        _timeToFirstFrame2 = win2.getFutureFlipTime(clock="now")
        frameN = -1
            
        # --- Run Routine "图片选择2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
            tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win2.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                
            # *image_11_p* updates
            if image_11_p.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                image_11_p.frameNStart = frameN  # exact frame index
                image_11_p.tStart = t  # local t and not account for scr refresh
                image_11_p.tStartRefresh = tThisFlipGlobal  # on global time
                win1.timeOnFlip(image_11_p, 'tStartRefresh')  # time at next scr refresh
                thisExp_p.timestampOnFlip(win1, 'image_11_p.started')
                image_11_p.status = STARTED
                image_11_p.setAutoDraw(True)

            if image_11_p.status == STARTED:
                if key_resp_c1.keys:  # 假设按键响应后停止
                    image_11_p.tStop = t
                    image_11_p.frameNStop = frameN
                    image_11_p.setAutoDraw(False)
                    image_11_p.status = FINISHED
            # *image_22_p* updates
            if image_22_p.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                image_22_p.frameNStart = frameN  # exact frame index
                image_22_p.tStart = t  # local t and not account for scr refresh
                image_22_p.tStartRefresh = tThisFlipGlobal  # on global time
                win1.timeOnFlip(image_22_p, 'tStartRefresh')  # time at next scr refresh
                thisExp_p.timestampOnFlip(win1, 'image_22_p.started')
                image_22_p.status = STARTED
                image_22_p.setAutoDraw(True)
            if image_22_p.status == STARTED:
                if key_resp_c1.keys:  # 假设按键响应后停止
                    image_22_p.tStop = t
                    image_22_p.frameNStop = frameN
                    image_22_p.setAutoDraw(False)
                    image_22_p.status = FINISHED
            # *image_33_p* updates
            if image_33_p.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                image_33_p.frameNStart = frameN  # exact frame index
                image_33_p.tStart = t  # local t and not account for scr refresh
                image_33_p.tStartRefresh = tThisFlipGlobal  # on global time
                win1.timeOnFlip(image_33_p, 'tStartRefresh')  # time at next scr refresh
                thisExp_p.timestampOnFlip(win1, 'image_33_p.started')
                image_33_p.status = STARTED
                image_33_p.setAutoDraw(True)
            if image_33_p.status == STARTED:
                if key_resp_c1.keys:  # 假设按键响应后停止
                    image_33_p.tStop = t
                    image_33_p.frameNStop = frameN
                    image_33_p.setAutoDraw(False)
                    image_33_p.status = FINISHED
            # *image_11_c* updates
            if image_11_c.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                image_11_c.frameNStart = frameN  # exact frame index
                image_11_c.tStart = t  # local t and not account for scr refresh
                image_11_c.tStartRefresh = tThisFlipGlobal  # on global time
                win2.timeOnFlip(image_11_c, 'tStartRefresh')  # time at next scr refresh
                thisExp_c.timestampOnFlip(win2, 'image_11_c.started')
                image_11_c.status = STARTED
                image_11_c.setAutoDraw(True)
            if image_11_c.status == STARTED:
                if key_resp_c1.keys:  # 假设按键响应后停止
                    image_11_c.tStop = t
                    image_11_c.frameNStop = frameN
                    image_11_c.setAutoDraw(False)
                    image_11_c.status = FINISHED

            # *image_22_c* updates
            if image_22_c.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                image_22_c.frameNStart = frameN  # exact frame index
                image_22_c.tStart = t  # local t and not account for scr refresh
                image_22_c.tStartRefresh = tThisFlipGlobal  # on global time
                win2.timeOnFlip(image_22_c, 'tStartRefresh')  # time at next scr refresh
                thisExp_c.timestampOnFlip(win2, 'image_22_c.started')
                image_22_c.status = STARTED
                image_22_c.setAutoDraw(True)

            if image_22_c.status == STARTED:
                if key_resp_c1.keys:  # 假设按键响应后停止
                    image_22_c.tStop = t
                    image_22_c.frameNStop = frameN
                    image_22_c.setAutoDraw(False)
                    image_22_c.status = FINISHED
            # *image_33_c* updates
            if image_33_c.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                image_33_c.frameNStart = frameN  # exact frame index
                image_33_c.tStart = t  # local t and not account for scr refresh
                image_33_c.tStartRefresh = tThisFlipGlobal  # on global time
                win2.timeOnFlip(image_33_c, 'tStartRefresh')  # time at next scr refresh
                thisExp_c.timestampOnFlip(win2, 'image_33_c.started')
                image_33_c.status = STARTED
                image_33_c.setAutoDraw(True)

            if image_33_c.status == STARTED:
                if key_resp_c1.keys:  # 假设按键响应后停止
                    image_33_c.tStop = t
                    image_33_c.frameNStop = frameN
                    image_33_c.setAutoDraw(False)
                    image_33_c.status = FINISHED
            # *key_resp_c1* updates
            waitOnFlip = False
            if key_resp_c1.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                key_resp_c1.frameNStart = frameN  # exact frame index
                key_resp_c1.tStart = t  # local t and not account for scr refresh
                key_resp_c1.tStartRefresh = tThisFlipGlobal  # on global time
                win2.timeOnFlip(key_resp_c1, 'tStartRefresh')  # time at next scr refresh
                thisExp_c.timestampOnFlip(win2, 'key_resp_c1.started')
                key_resp_c1.status = STARTED
                waitOnFlip = True
                win2.callOnFlip(key_resp_c1.clock.reset)  # t=0 on next screen flip
                win2.callOnFlip(key_resp_c1.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_c1.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_c1.getKeys(keyList=['1', '2', '3'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_c1_allKeys.extend(theseKeys)
                if len(_key_resp_c1_allKeys):
                    key_resp_c1.keys = _key_resp_c1_allKeys[-1].name  # just the last key pressed
                    key_resp_c1.rt = _key_resp_c1_allKeys[-1].rt
                    key_resp_c1.duration = _key_resp_c1_allKeys[-1].duration
                     # 判断按键是否正确
                    if key_resp_c1.keys == expected_key:
                        key_resp_c1.corr = 1  # 正确
                    else:
                        key_resp_c1.corr = 0  # 错误
                    print(f"Expected Key: {expected_key}, User Key: {key_resp_c1.keys}")
                    # 保存选择的图片路径和名称
                    if key_resp_c1.keys == '1':
                        selected_image_path_2 = object1
                    elif key_resp_c1.keys == '2':
                        selected_image_path_2 = object2
                    elif key_resp_c1.keys == '3':
                        selected_image_path_2 = object3
                    selected_image_name_2 = os.path.basename(selected_image_path_2)
                    # 保存所选图片的路径和名称到 thisExp_c
                    selected_image_paths_2.append(selected_image_path_2)
                    selected_image_names_2.append(selected_image_name_2)
                    thisExp_c.addData('selected_image_path_2', selected_image_path_2)
                    thisExp_c.addData('selected_image_name_2', selected_image_name_2)
                    continueRoutine = False  # a response ends the routine
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp_p.status = FINISHED
                thisExp_c.status = FINISHED
            if thisExp_p.status == FINISHED or thisExp_c.status == FINISHED or endExpNow:
                endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                return
                
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in 图片选择2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break
                        
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win1.flip()
                win2.flip()
                    
        # --- Ending Routine "图片选择2" ---
        for thisComponent in 图片选择2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)    
            # check responses
        if key_resp_c1.keys in ['', [], None]:  # No response was made
            key_resp_c1.keys = None
        # store data for trials_2 (TrialHandler)
        # Store data for thisExp_c (experiment for player c)
        thisExp_c.addData('key_resp_c1.keys', key_resp_c1.keys)
        thisExp_c.addData('key_resp_c1.corr', key_resp_c1.corr)
        if key_resp_c1.keys is not None:  # we had a response
            thisExp_c.addData('key_resp_c1.rt', key_resp_c1.rt)
            thisExp_c.addData('key_resp_c1.duration', key_resp_c1.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        routineTimer.reset()
        
        # --- Prepare to start Routine "反馈" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp_p.addData('反馈.started', globalClock.getTime(format='float'))
        thisExp_c.addData('反馈.started', globalClock.getTime(format='float'))
        # 设置反馈中使用的图片
        current_selected_image_p = None
        current_selected_image_c = None
        # 设置反馈中使用的图片
        if len(selected_image_paths_2) > 0:
            current_selected_image_p = selected_image_paths_2[-1]  # 获取最后一次选择的图片路径
            current_selected_image_c = selected_image_paths_2[-1]  # 玩家C也显示同样的图片
            # 如果有选择的图片，分别在 win1 和 win2 上显示这张图片
        if current_selected_image_p:
            image_111_win1.setImage(current_selected_image_p)
            image_111_win2.setImage(current_selected_image_c)
        # keep track of which components have finished
        反馈Components = [image_111_win1, image_111_win2]
        for thisComponent in 反馈Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame1 = win1.getFutureFlipTime(clock="now")
        _timeToFirstFrame2 = win2.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "反馈" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
            tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # *image_111_win1* updates
            if image_111_win1.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                image_111_win1.frameNStart = frameN
                image_111_win1.tStart = t
                image_111_win1.tStartRefresh = tThisFlipGlobal
                win1.timeOnFlip(image_111_win1, 'tStartRefresh')
                thisExp_p.timestampOnFlip(win1, 'image_111_win1.started')
                image_111_win1.status = STARTED
                image_111_win1.setAutoDraw(True)
            if image_111_win1.status == STARTED:
                if tThisFlipGlobal > image_111_win1.tStartRefresh + 2 - frameTolerance:
                    image_111_win1.tStop = t
                    image_111_win1.frameNStop = frameN
                    thisExp_p.timestampOnFlip(win1, 'image_111_win1.stopped')
                    image_111_win1.setAutoDraw(False)
            # *image_111_win2* updates
            if image_111_win2.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                image_111_win2.frameNStart = frameN
                image_111_win2.tStart = t
                image_111_win2.tStartRefresh = tThisFlipGlobal
                win2.timeOnFlip(image_111_win2, 'tStartRefresh')
                thisExp_c.timestampOnFlip(win2, 'image_111_win2.started')
                image_111_win2.status = STARTED
                image_111_win2.setAutoDraw(True)
            if image_111_win2.status == STARTED:
                if tThisFlipGlobal > image_111_win2.tStartRefresh + 2 - frameTolerance:
                    image_111_win2.tStop = t
                    image_111_win2.frameNStop = frameN
                    thisExp_c.timestampOnFlip(win2, 'image_111_win2.stopped')
                    image_111_win2.setAutoDraw(False)
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp_p.status = FINISHED
                thisExp_c.status = FINISHED
            if thisExp_p.status == FINISHED or thisExp_c.status == FINISHED or endExpNow:
                endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                return
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in 反馈Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
                
            # refresh the screen
            if continueRoutine:
                win1.flip()
                win2.flip()
        # --- Ending Routine "反馈" ---
        for thisComponent in 反馈Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # Save feedback routine data
        thisExp_p.addData('反馈.stopped', globalClock.getTime(format='float'))
        thisExp_c.addData('反馈.stopped', globalClock.getTime(format='float'))
        # 使用 non-slip timing，所以在本例程结束时重置计时器
        routineTimer.reset()
        
        # --- Prepare to start Routine "反馈2" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp_p.addData('反馈2.started', globalClock.getTime(format='float'))
        thisExp_c.addData('反馈2.started', globalClock.getTime(format='float'))
        
        # 设置反馈中使用的图片 - 笑脸或者哭脸
        feedback_image_path = None
        if key_resp_c1.corr == 1:  # 选择正确
            feedback_image_path = os.path.join(current_path, 'feedback', 'smile.png')  # 笑脸图片路径
        else:  # 选择错误
            feedback_image_path = os.path.join(current_path, 'feedback', 'cry.png')  # 哭脸图片路径
            
        # 在 win1 和 win2 上显示反馈图片
        if feedback_image_path:
            image_feedback_win1.setImage(feedback_image_path)
            image_feedback_win2.setImage(feedback_image_path)
        # keep track of which components have finished
        反馈2Components = [image_feedback_win1, image_feedback_win2]
        for thisComponent in 反馈2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame1 = win1.getFutureFlipTime(clock="now")
        _timeToFirstFrame2 = win2.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "反馈2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip1 = win1.getFutureFlipTime(clock=routineTimer)
            tThisFlip2 = win2.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win1.getFutureFlipTime(clock=None)
            frameN = frameN + 1  
            # *image_feedback_win1* updates
            if image_feedback_win1.status == NOT_STARTED and tThisFlip1 >= 0.0 - frameTolerance:
                image_feedback_win1.frameNStart = frameN
                image_feedback_win1.tStart = t
                image_feedback_win1.tStartRefresh = tThisFlipGlobal
                win1.timeOnFlip(image_feedback_win1, 'tStartRefresh')
                thisExp_p.timestampOnFlip(win1, 'image_feedback_win1.started')
                image_feedback_win1.status = STARTED
                image_feedback_win1.setAutoDraw(True)
            if image_feedback_win1.status == STARTED:
                if tThisFlipGlobal > image_feedback_win1.tStartRefresh + 2 - frameTolerance:
                    image_feedback_win1.tStop = t
                    image_feedback_win1.frameNStop = frameN
                    thisExp_p.timestampOnFlip(win1, 'image_feedback_win1.stopped')
                    image_feedback_win1.setAutoDraw(False)
            # *image_feedback_win2* updates
            if image_feedback_win2.status == NOT_STARTED and tThisFlip2 >= 0.0 - frameTolerance:
                image_feedback_win2.frameNStart = frameN
                image_feedback_win2.tStart = t
                image_feedback_win2.tStartRefresh = tThisFlipGlobal
                win2.timeOnFlip(image_feedback_win2, 'tStartRefresh')
                thisExp_c.timestampOnFlip(win2, 'image_feedback_win2.started')
                image_feedback_win2.status = STARTED
                image_feedback_win2.setAutoDraw(True)
            if image_feedback_win2.status == STARTED:
                if tThisFlipGlobal > image_feedback_win2.tStartRefresh + 2 - frameTolerance:
                    image_feedback_win2.tStop = t
                    image_feedback_win2.frameNStop = frameN
                    thisExp_c.timestampOnFlip(win2, 'image_feedback_win2.stopped')
                    image_feedback_win2.setAutoDraw(False)
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp_p.status = FINISHED
                thisExp_c.status = FINISHED
            if thisExp_p.status == FINISHED or thisExp_c.status == FINISHED or endExpNow:
                endExperiment(thisExp_p, thisExp_c, win1=win1, win2=win2)
                return
                
            # check if all components have finished
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in 反馈2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break
            # refresh the screen
            if continueRoutine:
                win1.flip()
                win2.flip()
        # --- Ending Routine "反馈2" ---
        for thisComponent in 反馈2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # Save feedback2 routine data
        thisExp_p.addData('反馈2.stopped', globalClock.getTime(format='float'))
        thisExp_c.addData('反馈2.stopped', globalClock.getTime(format='float'))
        # 使用 non-slip timing，所以在本例程结束时重置计时器
        routineTimer.reset()

        # Finalize and save the data entries for both experiment
        thisExp_p.nextEntry()
        thisExp_c.nextEntry()
        # 清除已选择的图片状态和列表
        for img in selected_images_win1:
            img.setAutoDraw(False)
            img.setImage(None)  # 清空图像
        for img in selected_images_win2:
            img.setAutoDraw(False)
            img.setImage(None)  # 清空图像
        # 清除已选择的图片列表
        selected_image_paths.clear()

        if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'trials_2'

    
def endExperiment(thisExp_p, thisExp_c, win1, win2):
    """
    End this experiment, performing final shut down operations for both parents and children data.

    Parameters
    ==========
    thisExp_p : psychopy.data.ExperimentHandler
        Handler object for the parents' data.
    thisExp_c : psychopy.data.ExperimentHandler
        Handler object for the children's data.
    win1, win2 : psychopy.visual.Window
        Windows for displaying parents' and children's content.
    """
    # Clear all auto-drawn components in both windows
    if win1 is not None:
        win1.clearAutoDraw()
        win1.flip()
    if win2 is not None:
        win2.clearAutoDraw()
        win2.flip()
    
    # Mark both experiment handlers as finished
    thisExp_p.status = FINISHED
    thisExp_c.status = FINISHED

    # Flush logs for both experiment handlers
    logging.flush()


def quit(thisExp_p, thisExp_c, win1=None, win2=None):
    """
    Fully quit, closing the window and ending the Python process for both parents and children experiments.
    
    Parameters
    ==========
    thisExp_p : psychopy.data.ExperimentHandler
        Handler object for the parents' data.
    thisExp_c : psychopy.data.ExperimentHandler
        Handler object for the children's data.
    win1, win2 : psychopy.visual.Window or None
        Windows for displaying parents' and children's content.
    """
    # Abort both experiment handlers to stop any further data recording
    thisExp_p.abort()
    thisExp_c.abort()
    
    # Close windows if they are provided
    if win1 is not None:
        win1.flip()
        win1.close()
    if win2 is not None:
        win2.flip()
        win2.close()
    
    # Flush logs to ensure data is properly saved
    logging.flush()
    
    # Quit the PsychoPy core and end the Python process
    core.quit()


if __name__ == '__main__':
    expInfo = showExpInfoDlg(expInfo=expInfo)
    
    # 初始化两个 ExperimentHandler：thisExp_p 和 thisExp_c
    thisExp_p, thisExp_c = setupData(expInfo=expInfo)
    
    # 分别为 parents 和 children 创建日志文件
    logFile_p = setupLogging(filename=thisExp_p.dataFileName)
    logFile_c = setupLogging(filename=thisExp_c.dataFileName)
    
    # 初始化两个窗口 win1 和 win2
    win1, win2 = setupWindow(expInfo=expInfo)
    
    # 创建 globalClock 对象
    globalClock = core.Clock()
    
    # 运行实验
    run(
        expInfo=expInfo, 
        thisExp_p=thisExp_p, 
        thisExp_c=thisExp_c, 
        win1=win1,
        win2=win2,
        globalClock=globalClock  # 传入 core.Clock 对象
    )
    
    # 保存两个文件
    thisExp_p.saveAsWideText(thisExp_p.dataFileName + '.csv')
    thisExp_c.saveAsWideText(thisExp_c.dataFileName + '.csv')
    
    # 结束实验并关闭窗口
    quit(thisExp_p=thisExp_p, thisExp_c=thisExp_c, win1=win1, win2=win2)
