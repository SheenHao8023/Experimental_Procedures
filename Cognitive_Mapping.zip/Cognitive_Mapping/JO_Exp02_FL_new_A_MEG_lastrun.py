﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on Wed Jun 29 09:07:19 2022
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'JO_Exp02_FL_'  # from the Builder filename that created this script
expInfo = {'participant': '1001', 'Name': '', 'Location': ['NBH', 'PKU', 'BCAS'], 'session': ['1', '2', '3', '4', '5', '6'], 'time': ['1', '2', '3', '4', '5', '6']}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/Data_Exp02_FL/%s%s_%s_%s_%s' % (expName, expInfo['session'], expInfo['participant'], expInfo['date'], 'main')

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/jianxinou/Desktop/Procedure_0612/JO_Exp02_FL_new_A_MEG_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1680, 1050], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color='#C8C8C8', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "instruction"
instructionClock = core.Clock()
instr_key_resp = keyboard.Keyboard()
session = str(int(expInfo['session']))
partic = str(int(expInfo['participant'])%10)

thisExp.addData("session",session)
thisExp.addData("partic",partic)

condition_file = 'Lists/Exp_FL/List_JO_Exp02_FL_submod' + partic + '_' +session+'.xlsx'


from psychopy import parallel  ### turn on if MEG scanning

location = expInfo['Location']
if location == 'PKU':
    address = 0xCFF8
elif location == 'BCAS':
    address = 0xD020
elif location == 'NBH':
    address = 0x0378
else:
    print('Please choose your location for MEG scanning')
port = parallel.ParallelPort(address=address)  ### turn on if MEG scanning
port.setData(0)   ### turn on if MEG scanning
image_6 = visual.ImageStim(
    win=win,
    name='image_6', 
    image='pic/instr/Slide101.png', mask=None,
    ori=0.0, pos=(0, 0), size=(1.3333333, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)

# Initialize components for Routine "FL_instr"
FL_instrClock = core.Clock()
instr003 = visual.ImageStim(
    win=win,
    name='instr003', 
    image='pic/instr/Slide7.png', mask=None,
    ori=0.0, pos=(0, 0), size=(1.3333333333333, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
key_resp_11 = keyboard.Keyboard()

# Initialize components for Routine "local"
localClock = core.Clock()
image_8 = visual.ImageStim(
    win=win,
    name='image_8', 
    image='pic/instr/instr_learn_nanjing.png', mask=None,
    ori=0.0, pos=(0, 0), size=(1.3333333, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
key_resp_13 = keyboard.Keyboard()

# Initialize components for Routine "FL_fixation"
FL_fixationClock = core.Clock()
text_2 = visual.TextStim(win=win, name='text_2',
    text='+',
    font='SimHei',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "FL_pic"
FL_picClock = core.Clock()
FL_picture = visual.ImageStim(
    win=win,
    name='FL_picture', 
    image='sin', mask=None,
    ori=0.0, pos=(0, 0), size=(0.7, 0.7),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "FL_task"
FL_taskClock = core.Clock()
FL_left = visual.TextStim(win=win, name='FL_left',
    text='',
    font='simHei',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
FL_resp = keyboard.Keyboard()
j = -1;
accumu_FL_acc = 0
accumu_FL_acc_trial = 0

# Initialize components for Routine "FL_feedback"
FL_feedbackClock = core.Clock()
FL_feedback_text = visual.TextStim(win=win, name='FL_feedback_text',
    text=None,
    font='simHei',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "FL_feedback_begin"
FL_feedback_beginClock = core.Clock()
FL_feedback_begin_text = visual.TextStim(win=win, name='FL_feedback_begin_text',
    text='\n\n\n\n\n\n\n请按任意键继续',
    font='simHei',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
text_5 = visual.TextStim(win=win, name='text_5',
    text=None,
    font='simHei',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_12 = keyboard.Keyboard()

# Initialize components for Routine "seq_play_ITI"
seq_play_ITIClock = core.Clock()
seq_play_iti_ = visual.TextStim(win=win, name='seq_play_iti_',
    text=None,
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "FL_block_feedback"
FL_block_feedbackClock = core.Clock()
FL_block_feedback_text = visual.TextStim(win=win, name='FL_block_feedback_text',
    text=None,
    font='simHei',
    pos=(0, 0), height=0.15, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_8 = keyboard.Keyboard()
b = 0

acc_FL_trial = 0
acc_FL_all = 0


text_6 = visual.TextStim(win=win, name='text_6',
    text='您这一部分的正确率：\n\n\n\n\n\n',
    font='simHei',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "local"
localClock = core.Clock()
image_8 = visual.ImageStim(
    win=win,
    name='image_8', 
    image='pic/instr/instr_learn_nanjing.png', mask=None,
    ori=0.0, pos=(0, 0), size=(1.3333333, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
key_resp_13 = keyboard.Keyboard()

# Initialize components for Routine "rest_ins"
rest_insClock = core.Clock()
image_7 = visual.ImageStim(
    win=win,
    name='image_7', 
    image='pic/instr/Slide9.png', mask=None,
    ori=0.0, pos=(0, 0), size=(1.333333, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instruction"-------
continueRoutine = True
# update component parameters for each repeat
instr_key_resp.keys = []
instr_key_resp.rt = []
_instr_key_resp_allKeys = []
# keep track of which components have finished
instructionComponents = [instr_key_resp, image_6]
for thisComponent in instructionComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
instructionClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "instruction"-------
while continueRoutine:
    # get current time
    t = instructionClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=instructionClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instr_key_resp* updates
    waitOnFlip = False
    if instr_key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instr_key_resp.frameNStart = frameN  # exact frame index
        instr_key_resp.tStart = t  # local t and not account for scr refresh
        instr_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instr_key_resp, 'tStartRefresh')  # time at next scr refresh
        instr_key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instr_key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instr_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instr_key_resp.status == STARTED and not waitOnFlip:
        theseKeys = instr_key_resp.getKeys(keyList=['4', '3'], waitRelease=False)
        _instr_key_resp_allKeys.extend(theseKeys)
        if len(_instr_key_resp_allKeys):
            instr_key_resp.keys = _instr_key_resp_allKeys[-1].name  # just the last key pressed
            instr_key_resp.rt = _instr_key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *image_6* updates
    if image_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_6.frameNStart = frameN  # exact frame index
        image_6.tStart = t  # local t and not account for scr refresh
        image_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_6, 'tStartRefresh')  # time at next scr refresh
        image_6.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructionComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instruction"-------
for thisComponent in instructionComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if instr_key_resp.keys in ['', [], None]:  # No response was made
    instr_key_resp.keys = None
thisExp.addData('instr_key_resp.keys',instr_key_resp.keys)
if instr_key_resp.keys != None:  # we had a response
    thisExp.addData('instr_key_resp.rt', instr_key_resp.rt)
thisExp.addData('instr_key_resp.started', instr_key_resp.tStartRefresh)
thisExp.addData('instr_key_resp.stopped', instr_key_resp.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('image_6.started', image_6.tStartRefresh)
thisExp.addData('image_6.stopped', image_6.tStopRefresh)
# the Routine "instruction" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "FL_instr"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_11.keys = []
key_resp_11.rt = []
_key_resp_11_allKeys = []
# keep track of which components have finished
FL_instrComponents = [instr003, key_resp_11]
for thisComponent in FL_instrComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
FL_instrClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "FL_instr"-------
while continueRoutine:
    # get current time
    t = FL_instrClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=FL_instrClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instr003* updates
    if instr003.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instr003.frameNStart = frameN  # exact frame index
        instr003.tStart = t  # local t and not account for scr refresh
        instr003.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instr003, 'tStartRefresh')  # time at next scr refresh
        instr003.setAutoDraw(True)
    
    # *key_resp_11* updates
    waitOnFlip = False
    if key_resp_11.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_11.frameNStart = frameN  # exact frame index
        key_resp_11.tStart = t  # local t and not account for scr refresh
        key_resp_11.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_11, 'tStartRefresh')  # time at next scr refresh
        key_resp_11.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_11.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_11.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_11.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_11.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_11_allKeys.extend(theseKeys)
        if len(_key_resp_11_allKeys):
            key_resp_11.keys = _key_resp_11_allKeys[-1].name  # just the last key pressed
            key_resp_11.rt = _key_resp_11_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in FL_instrComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "FL_instr"-------
for thisComponent in FL_instrComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('instr003.started', instr003.tStartRefresh)
thisExp.addData('instr003.stopped', instr003.tStopRefresh)
# check responses
if key_resp_11.keys in ['', [], None]:  # No response was made
    key_resp_11.keys = None
thisExp.addData('key_resp_11.keys',key_resp_11.keys)
if key_resp_11.keys != None:  # we had a response
    thisExp.addData('key_resp_11.rt', key_resp_11.rt)
thisExp.addData('key_resp_11.started', key_resp_11.tStartRefresh)
thisExp.addData('key_resp_11.stopped', key_resp_11.tStopRefresh)
thisExp.nextEntry()
# the Routine "FL_instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "local"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_13.keys = []
key_resp_13.rt = []
_key_resp_13_allKeys = []
# keep track of which components have finished
localComponents = [image_8, key_resp_13]
for thisComponent in localComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
localClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "local"-------
while continueRoutine:
    # get current time
    t = localClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=localClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_8* updates
    if image_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_8.frameNStart = frameN  # exact frame index
        image_8.tStart = t  # local t and not account for scr refresh
        image_8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_8, 'tStartRefresh')  # time at next scr refresh
        image_8.setAutoDraw(True)
    
    # *key_resp_13* updates
    waitOnFlip = False
    if key_resp_13.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_13.frameNStart = frameN  # exact frame index
        key_resp_13.tStart = t  # local t and not account for scr refresh
        key_resp_13.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_13, 'tStartRefresh')  # time at next scr refresh
        key_resp_13.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_13.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_13.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_13.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_13.getKeys(keyList=['y'], waitRelease=False)
        _key_resp_13_allKeys.extend(theseKeys)
        if len(_key_resp_13_allKeys):
            key_resp_13.keys = _key_resp_13_allKeys[-1].name  # just the last key pressed
            key_resp_13.rt = _key_resp_13_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in localComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "local"-------
for thisComponent in localComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_8.started', image_8.tStartRefresh)
thisExp.addData('image_8.stopped', image_8.tStopRefresh)
# check responses
if key_resp_13.keys in ['', [], None]:  # No response was made
    key_resp_13.keys = None
thisExp.addData('key_resp_13.keys',key_resp_13.keys)
if key_resp_13.keys != None:  # we had a response
    thisExp.addData('key_resp_13.rt', key_resp_13.rt)
thisExp.addData('key_resp_13.started', key_resp_13.tStartRefresh)
thisExp.addData('key_resp_13.stopped', key_resp_13.tStopRefresh)
thisExp.nextEntry()
# the Routine "local" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
FL_block = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions(condition_file),
    seed=None, name='FL_block')
thisExp.addLoop(FL_block)  # add the loop to the experiment
thisFL_block = FL_block.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisFL_block.rgb)
if thisFL_block != None:
    for paramName in thisFL_block:
        exec('{} = thisFL_block[paramName]'.format(paramName))

for thisFL_block in FL_block:
    currentLoop = FL_block
    # abbreviate parameter names if possible (e.g. rgb = thisFL_block.rgb)
    if thisFL_block != None:
        for paramName in thisFL_block:
            exec('{} = thisFL_block[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    trials = data.TrialHandler(nReps=99.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials')
    thisExp.addLoop(trials)  # add the loop to the experiment
    thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    for thisTrial in trials:
        currentLoop = trials
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                exec('{} = thisTrial[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "FL_fixation"-------
        continueRoutine = True
        routineTimer.add(0.200000)
        # update component parameters for each repeat
        # keep track of which components have finished
        FL_fixationComponents = [text_2]
        for thisComponent in FL_fixationComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        FL_fixationClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "FL_fixation"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = FL_fixationClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=FL_fixationClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_2* updates
            if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_2.frameNStart = frameN  # exact frame index
                text_2.tStart = t  # local t and not account for scr refresh
                text_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
                text_2.setAutoDraw(True)
            if text_2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_2.tStartRefresh + 0.2-frameTolerance:
                    # keep track of stop time/frame for later
                    text_2.tStop = t  # not accounting for scr refresh
                    text_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(text_2, 'tStopRefresh')  # time at next scr refresh
                    text_2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FL_fixationComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "FL_fixation"-------
        for thisComponent in FL_fixationComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        trials.addData('text_2.started', text_2.tStartRefresh)
        trials.addData('text_2.stopped', text_2.tStopRefresh)
        
        # ------Prepare to start Routine "FL_pic"-------
        continueRoutine = True
        routineTimer.add(0.800000)
        # update component parameters for each repeat
        FL_picture.setImage(FL_pic)
        startchannel=int(picture)
        thisExp.addData('startchannel', startchannel)
        port.setData(startchannel)  ###
        core.wait(0.05)
        port.setData(0) ## also see End Routine
        # keep track of which components have finished
        FL_picComponents = [FL_picture]
        for thisComponent in FL_picComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        FL_picClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "FL_pic"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = FL_picClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=FL_picClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *FL_picture* updates
            if FL_picture.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                FL_picture.frameNStart = frameN  # exact frame index
                FL_picture.tStart = t  # local t and not account for scr refresh
                FL_picture.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(FL_picture, 'tStartRefresh')  # time at next scr refresh
                FL_picture.setAutoDraw(True)
            if FL_picture.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > FL_picture.tStartRefresh + 0.8-frameTolerance:
                    # keep track of stop time/frame for later
                    FL_picture.tStop = t  # not accounting for scr refresh
                    FL_picture.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(FL_picture, 'tStopRefresh')  # time at next scr refresh
                    FL_picture.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FL_picComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "FL_pic"-------
        for thisComponent in FL_picComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        trials.addData('FL_picture.started', FL_picture.tStartRefresh)
        trials.addData('FL_picture.stopped', FL_picture.tStopRefresh)
        
        # ------Prepare to start Routine "FL_task"-------
        continueRoutine = True
        routineTimer.add(1.000000)
        # update component parameters for each repeat
        FL_left.setText(FL_label_left)
        FL_resp.keys = []
        FL_resp.rt = []
        _FL_resp_allKeys = []
        port.setData(61)  ###
        core.wait(0.02)
        port.setData(0)  ###
        
        # keep track of which components have finished
        FL_taskComponents = [FL_left, FL_resp]
        for thisComponent in FL_taskComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        FL_taskClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "FL_task"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = FL_taskClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=FL_taskClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *FL_left* updates
            if FL_left.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                FL_left.frameNStart = frameN  # exact frame index
                FL_left.tStart = t  # local t and not account for scr refresh
                FL_left.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(FL_left, 'tStartRefresh')  # time at next scr refresh
                FL_left.setAutoDraw(True)
            if FL_left.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > FL_left.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    FL_left.tStop = t  # not accounting for scr refresh
                    FL_left.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(FL_left, 'tStopRefresh')  # time at next scr refresh
                    FL_left.setAutoDraw(False)
            
            # *FL_resp* updates
            waitOnFlip = False
            if FL_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                FL_resp.frameNStart = frameN  # exact frame index
                FL_resp.tStart = t  # local t and not account for scr refresh
                FL_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(FL_resp, 'tStartRefresh')  # time at next scr refresh
                FL_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(FL_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(FL_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if FL_resp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > FL_resp.tStartRefresh + 1-frameTolerance:
                    # keep track of stop time/frame for later
                    FL_resp.tStop = t  # not accounting for scr refresh
                    FL_resp.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(FL_resp, 'tStopRefresh')  # time at next scr refresh
                    FL_resp.status = FINISHED
            if FL_resp.status == STARTED and not waitOnFlip:
                theseKeys = FL_resp.getKeys(keyList=['4', '3'], waitRelease=False)
                _FL_resp_allKeys.extend(theseKeys)
                if len(_FL_resp_allKeys):
                    FL_resp.keys = _FL_resp_allKeys[-1].name  # just the last key pressed
                    FL_resp.rt = _FL_resp_allKeys[-1].rt
                    # was this correct?
                    if (FL_resp.keys == str(corr_key)) or (FL_resp.keys == corr_key):
                        FL_resp.corr = 1
                    else:
                        FL_resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FL_taskComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "FL_task"-------
        for thisComponent in FL_taskComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        trials.addData('FL_left.started', FL_left.tStartRefresh)
        trials.addData('FL_left.stopped', FL_left.tStopRefresh)
        # check responses
        if FL_resp.keys in ['', [], None]:  # No response was made
            FL_resp.keys = None
            # was no response the correct answer?!
            if str(corr_key).lower() == 'none':
               FL_resp.corr = 1;  # correct non-response
            else:
               FL_resp.corr = 0;  # failed to respond (incorrectly)
        # store data for trials (TrialHandler)
        trials.addData('FL_resp.keys',FL_resp.keys)
        trials.addData('FL_resp.corr', FL_resp.corr)
        if FL_resp.keys != None:  # we had a response
            trials.addData('FL_resp.rt', FL_resp.rt)
        trials.addData('FL_resp.started', FL_resp.tStartRefresh)
        trials.addData('FL_resp.stopped', FL_resp.tStopRefresh)
        port.setData(62)  ###
        core.wait(0.02)
        port.setData(0)  
        j = j + 1;
        if FL_resp.keys is None:
            FL_fb_dur1 = 1.5
            FL_fb_dur2 = 9999999999
            FL_f_text = "请尽快按键"
            FL_accuracy = 0
        elif FL_resp.corr == 0:
            FL_fb_dur1 = 1.5
            FL_fb_dur2 = 99999999
            FL_f_text = "请认真看图片"
            FL_accuracy = FL_resp.corr   
        elif FL_resp.corr == 1:
            FL_fb_dur1 = 0
            FL_fb_dur2 = 0
            FL_f_text = ""
            FL_accuracy = FL_resp.corr 
        
        accumu_FL_acc_trial = accumu_FL_acc_trial + FL_accuracy
        accumu_FL_acc = accumu_FL_acc_trial/(j+1)
        
        thisExp.addData("FL_fb_dur1",FL_fb_dur1)
        thisExp.addData("FL_fb_dur2",FL_fb_dur2)
        thisExp.addData("FL_accuracy",FL_accuracy)
        thisExp.addData("accumu_FL_acc",accumu_FL_acc)
        
        # ------Prepare to start Routine "FL_feedback"-------
        continueRoutine = True
        # update component parameters for each repeat
        FL_feedback_text.setText(FL_f_text)
        # keep track of which components have finished
        FL_feedbackComponents = [FL_feedback_text]
        for thisComponent in FL_feedbackComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        FL_feedbackClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "FL_feedback"-------
        while continueRoutine:
            # get current time
            t = FL_feedbackClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=FL_feedbackClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *FL_feedback_text* updates
            if FL_feedback_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                FL_feedback_text.frameNStart = frameN  # exact frame index
                FL_feedback_text.tStart = t  # local t and not account for scr refresh
                FL_feedback_text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(FL_feedback_text, 'tStartRefresh')  # time at next scr refresh
                FL_feedback_text.setAutoDraw(True)
            if FL_feedback_text.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > FL_feedback_text.tStartRefresh + FL_fb_dur1-frameTolerance:
                    # keep track of stop time/frame for later
                    FL_feedback_text.tStop = t  # not accounting for scr refresh
                    FL_feedback_text.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(FL_feedback_text, 'tStopRefresh')  # time at next scr refresh
                    FL_feedback_text.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FL_feedbackComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "FL_feedback"-------
        for thisComponent in FL_feedbackComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        trials.addData('FL_feedback_text.started', FL_feedback_text.tStartRefresh)
        trials.addData('FL_feedback_text.stopped', FL_feedback_text.tStopRefresh)
        # the Routine "FL_feedback" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "FL_feedback_begin"-------
        continueRoutine = True
        # update component parameters for each repeat
        key_resp_12.keys = []
        key_resp_12.rt = []
        _key_resp_12_allKeys = []
        text_5.setText(FL_f_text)
        # keep track of which components have finished
        FL_feedback_beginComponents = [FL_feedback_begin_text, text_5, key_resp_12]
        for thisComponent in FL_feedback_beginComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        FL_feedback_beginClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "FL_feedback_begin"-------
        while continueRoutine:
            # get current time
            t = FL_feedback_beginClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=FL_feedback_beginClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *FL_feedback_begin_text* updates
            if FL_feedback_begin_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                FL_feedback_begin_text.frameNStart = frameN  # exact frame index
                FL_feedback_begin_text.tStart = t  # local t and not account for scr refresh
                FL_feedback_begin_text.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(FL_feedback_begin_text, 'tStartRefresh')  # time at next scr refresh
                FL_feedback_begin_text.setAutoDraw(True)
            if FL_feedback_begin_text.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > FL_feedback_begin_text.tStartRefresh + FL_fb_dur2-frameTolerance:
                    # keep track of stop time/frame for later
                    FL_feedback_begin_text.tStop = t  # not accounting for scr refresh
                    FL_feedback_begin_text.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(FL_feedback_begin_text, 'tStopRefresh')  # time at next scr refresh
                    FL_feedback_begin_text.setAutoDraw(False)
            
            # *text_5* updates
            if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_5.frameNStart = frameN  # exact frame index
                text_5.tStart = t  # local t and not account for scr refresh
                text_5.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
                text_5.setAutoDraw(True)
            if text_5.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_5.tStartRefresh + FL_fb_dur2-frameTolerance:
                    # keep track of stop time/frame for later
                    text_5.tStop = t  # not accounting for scr refresh
                    text_5.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(text_5, 'tStopRefresh')  # time at next scr refresh
                    text_5.setAutoDraw(False)
            
            # *key_resp_12* updates
            waitOnFlip = False
            if key_resp_12.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_12.frameNStart = frameN  # exact frame index
                key_resp_12.tStart = t  # local t and not account for scr refresh
                key_resp_12.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_12, 'tStartRefresh')  # time at next scr refresh
                key_resp_12.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_12.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_12.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_12.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_resp_12.tStartRefresh + FL_fb_dur2-frameTolerance:
                    # keep track of stop time/frame for later
                    key_resp_12.tStop = t  # not accounting for scr refresh
                    key_resp_12.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(key_resp_12, 'tStopRefresh')  # time at next scr refresh
                    key_resp_12.status = FINISHED
            if key_resp_12.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_12.getKeys(keyList=['3', '4'], waitRelease=False)
                _key_resp_12_allKeys.extend(theseKeys)
                if len(_key_resp_12_allKeys):
                    key_resp_12.keys = _key_resp_12_allKeys[-1].name  # just the last key pressed
                    key_resp_12.rt = _key_resp_12_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in FL_feedback_beginComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "FL_feedback_begin"-------
        for thisComponent in FL_feedback_beginComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        trials.addData('FL_feedback_begin_text.started', FL_feedback_begin_text.tStartRefresh)
        trials.addData('FL_feedback_begin_text.stopped', FL_feedback_begin_text.tStopRefresh)
        trials.addData('text_5.started', text_5.tStartRefresh)
        trials.addData('text_5.stopped', text_5.tStopRefresh)
        # check responses
        if key_resp_12.keys in ['', [], None]:  # No response was made
            key_resp_12.keys = None
        trials.addData('key_resp_12.keys',key_resp_12.keys)
        if key_resp_12.keys != None:  # we had a response
            trials.addData('key_resp_12.rt', key_resp_12.rt)
        trials.addData('key_resp_12.started', key_resp_12.tStartRefresh)
        trials.addData('key_resp_12.stopped', key_resp_12.tStopRefresh)
        # the Routine "FL_feedback_begin" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "seq_play_ITI"-------
        continueRoutine = True
        # update component parameters for each repeat
        ITI = randint(300, 500)/1000
        thisExp.addData("ITI", ITI)
        
        
        # keep track of which components have finished
        seq_play_ITIComponents = [seq_play_iti_]
        for thisComponent in seq_play_ITIComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        seq_play_ITIClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "seq_play_ITI"-------
        while continueRoutine:
            # get current time
            t = seq_play_ITIClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=seq_play_ITIClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *seq_play_iti_* updates
            if seq_play_iti_.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                seq_play_iti_.frameNStart = frameN  # exact frame index
                seq_play_iti_.tStart = t  # local t and not account for scr refresh
                seq_play_iti_.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(seq_play_iti_, 'tStartRefresh')  # time at next scr refresh
                seq_play_iti_.setAutoDraw(True)
            if seq_play_iti_.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > seq_play_iti_.tStartRefresh + ITI-frameTolerance:
                    # keep track of stop time/frame for later
                    seq_play_iti_.tStop = t  # not accounting for scr refresh
                    seq_play_iti_.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(seq_play_iti_, 'tStopRefresh')  # time at next scr refresh
                    seq_play_iti_.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in seq_play_ITIComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "seq_play_ITI"-------
        for thisComponent in seq_play_ITIComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        trials.addData('seq_play_iti_.started', seq_play_iti_.tStartRefresh)
        trials.addData('seq_play_iti_.stopped', seq_play_iti_.tStopRefresh)
        if FL_resp.corr == 1:
            trials.finished = True
        # the Routine "seq_play_ITI" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 99.0 repeats of 'trials'
    
    # get names of stimulus parameters
    if trials.trialList in ([], [None], None):
        params = []
    else:
        params = trials.trialList[0].keys()
    # save data for this loop
    trials.saveAsText(filename + 'trials.csv', delim=',',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'FL_block'

# get names of stimulus parameters
if FL_block.trialList in ([], [None], None):
    params = []
else:
    params = FL_block.trialList[0].keys()
# save data for this loop
FL_block.saveAsText(filename + 'FL_block.csv', delim=',',
    stimOut=params,
    dataOut=['n','all_mean','all_std', 'all_raw'])

# ------Prepare to start Routine "FL_block_feedback"-------
continueRoutine = True
routineTimer.add(3.000000)
# update component parameters for each repeat
key_resp_8.keys = []
key_resp_8.rt = []
_key_resp_8_allKeys = []
b = b + 1

acc_FL_trial = acc_FL_trial + accumu_FL_acc_trial

acc_FL_all = acc_FL_trial / (b*210)

FL_block_fk_text = "{:.1f}%".format(accumu_FL_acc*100)

FL_block_feedback_text.setText(FL_block_fk_text)

thisExp.addData("acc_FL_all",acc_FL_all)

j = -1
accumu_FL_acc = 0
accumu_FL_acc_trial = 0

# keep track of which components have finished
FL_block_feedbackComponents = [FL_block_feedback_text, key_resp_8, text_6]
for thisComponent in FL_block_feedbackComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
FL_block_feedbackClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "FL_block_feedback"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = FL_block_feedbackClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=FL_block_feedbackClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *FL_block_feedback_text* updates
    if FL_block_feedback_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        FL_block_feedback_text.frameNStart = frameN  # exact frame index
        FL_block_feedback_text.tStart = t  # local t and not account for scr refresh
        FL_block_feedback_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(FL_block_feedback_text, 'tStartRefresh')  # time at next scr refresh
        FL_block_feedback_text.setAutoDraw(True)
    if FL_block_feedback_text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > FL_block_feedback_text.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            FL_block_feedback_text.tStop = t  # not accounting for scr refresh
            FL_block_feedback_text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(FL_block_feedback_text, 'tStopRefresh')  # time at next scr refresh
            FL_block_feedback_text.setAutoDraw(False)
    
    # *key_resp_8* updates
    waitOnFlip = False
    if key_resp_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_8.frameNStart = frameN  # exact frame index
        key_resp_8.tStart = t  # local t and not account for scr refresh
        key_resp_8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_8, 'tStartRefresh')  # time at next scr refresh
        key_resp_8.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_8.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_8.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_8.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > key_resp_8.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            key_resp_8.tStop = t  # not accounting for scr refresh
            key_resp_8.frameNStop = frameN  # exact frame index
            win.timeOnFlip(key_resp_8, 'tStopRefresh')  # time at next scr refresh
            key_resp_8.status = FINISHED
    if key_resp_8.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_8.getKeys(keyList=['1'], waitRelease=False)
        _key_resp_8_allKeys.extend(theseKeys)
        if len(_key_resp_8_allKeys):
            key_resp_8.keys = _key_resp_8_allKeys[-1].name  # just the last key pressed
            key_resp_8.rt = _key_resp_8_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *text_6* updates
    if text_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_6.frameNStart = frameN  # exact frame index
        text_6.tStart = t  # local t and not account for scr refresh
        text_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_6, 'tStartRefresh')  # time at next scr refresh
        text_6.setAutoDraw(True)
    if text_6.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_6.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            text_6.tStop = t  # not accounting for scr refresh
            text_6.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_6, 'tStopRefresh')  # time at next scr refresh
            text_6.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in FL_block_feedbackComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "FL_block_feedback"-------
for thisComponent in FL_block_feedbackComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('FL_block_feedback_text.started', FL_block_feedback_text.tStartRefresh)
thisExp.addData('FL_block_feedback_text.stopped', FL_block_feedback_text.tStopRefresh)
# check responses
if key_resp_8.keys in ['', [], None]:  # No response was made
    key_resp_8.keys = None
thisExp.addData('key_resp_8.keys',key_resp_8.keys)
if key_resp_8.keys != None:  # we had a response
    thisExp.addData('key_resp_8.rt', key_resp_8.rt)
thisExp.addData('key_resp_8.started', key_resp_8.tStartRefresh)
thisExp.addData('key_resp_8.stopped', key_resp_8.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('text_6.started', text_6.tStartRefresh)
thisExp.addData('text_6.stopped', text_6.tStopRefresh)

# ------Prepare to start Routine "local"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_13.keys = []
key_resp_13.rt = []
_key_resp_13_allKeys = []
# keep track of which components have finished
localComponents = [image_8, key_resp_13]
for thisComponent in localComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
localClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "local"-------
while continueRoutine:
    # get current time
    t = localClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=localClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_8* updates
    if image_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_8.frameNStart = frameN  # exact frame index
        image_8.tStart = t  # local t and not account for scr refresh
        image_8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_8, 'tStartRefresh')  # time at next scr refresh
        image_8.setAutoDraw(True)
    
    # *key_resp_13* updates
    waitOnFlip = False
    if key_resp_13.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_13.frameNStart = frameN  # exact frame index
        key_resp_13.tStart = t  # local t and not account for scr refresh
        key_resp_13.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_13, 'tStartRefresh')  # time at next scr refresh
        key_resp_13.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_13.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_13.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_13.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_13.getKeys(keyList=['y'], waitRelease=False)
        _key_resp_13_allKeys.extend(theseKeys)
        if len(_key_resp_13_allKeys):
            key_resp_13.keys = _key_resp_13_allKeys[-1].name  # just the last key pressed
            key_resp_13.rt = _key_resp_13_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in localComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "local"-------
for thisComponent in localComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_8.started', image_8.tStartRefresh)
thisExp.addData('image_8.stopped', image_8.tStopRefresh)
# check responses
if key_resp_13.keys in ['', [], None]:  # No response was made
    key_resp_13.keys = None
thisExp.addData('key_resp_13.keys',key_resp_13.keys)
if key_resp_13.keys != None:  # we had a response
    thisExp.addData('key_resp_13.rt', key_resp_13.rt)
thisExp.addData('key_resp_13.started', key_resp_13.tStartRefresh)
thisExp.addData('key_resp_13.stopped', key_resp_13.tStopRefresh)
thisExp.nextEntry()
# the Routine "local" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "rest_ins"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
rest_insComponents = [image_7]
for thisComponent in rest_insComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
rest_insClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "rest_ins"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = rest_insClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=rest_insClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_7* updates
    if image_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_7.frameNStart = frameN  # exact frame index
        image_7.tStart = t  # local t and not account for scr refresh
        image_7.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_7, 'tStartRefresh')  # time at next scr refresh
        image_7.setAutoDraw(True)
    if image_7.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_7.tStartRefresh + 2-frameTolerance:
            # keep track of stop time/frame for later
            image_7.tStop = t  # not accounting for scr refresh
            image_7.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_7, 'tStopRefresh')  # time at next scr refresh
            image_7.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in rest_insComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "rest_ins"-------
for thisComponent in rest_insComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_7.started', image_7.tStartRefresh)
thisExp.addData('image_7.stopped', image_7.tStopRefresh)

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
